--[[ ErrorReporter — 错误自动收集（报告目录：Media/ZiYan/ZYCV/res/错误报告）
  设计要点（多 Agent 开发 2026-09-11 需求）：
    · 真实产生错误时立即结构化落盘，不依赖网络/Web 是否可用
    · 报告目录：默认 /private/var/mobile/Media/ZiYan/ZYCV/res/错误报告/<事件ID>/
    · 每份报告：report.json + context.txt + script.txt（有业务脚本时）
    · 保留 3 天：allow-not-delete 未到期日志；删除记录写 _cleanup.log
    · 失败绝不中断业务：所有 io 走 pcall，任何路径都不抛错

  事件类型：script_error（脚本抛错）/ timeout（超时）/ stop（强制停止）/
            hang（卡死）/ crash（进程崩溃，由宿主/守护补写）/
            cold_start（冷启动）/ sb_restart（SpringBoard 重启）/ abnormal_exit（异常退出）

  对外接口：
    M.report(err_type, message, extra)   → 事件ID, 报告目录
    M.handle(script_path, err)           → 包装脚本错误的快捷入口
    M.purge(retention_days)              → 扫描并删除到期报告
    M.list()                             → 未删除报告的事件ID列表
]]

local M = { name = "ErrorReporter", version = "1.0.0" }

-- rootless（.61 等）上 mkdir/ls/rm 可能只存在于 /var/jb/usr/bin，
-- 而 io.popen 的 sh 不继承登录 PATH —— 所有 shell 调用必须自带 PATH 前缀。
local SH_PATH = "PATH=/var/jb/usr/bin:/var/jb/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH "


-- 停止事件去重旗标文件名（control.lua 引用；每次新会话启动时清除）
M.STOP_GUARD = ".ziyan_error_reporter_stop_done"

---------------------------------------------------------------------------
-- 平台无关小工具（对齐 modules/ 下其它模块的降级习惯）
---------------------------------------------------------------------------

local function is_utf8()
  local f = _G.string and _G.string.format
  if type(f) ~= "function" then return false end
  return select("#", f("%q", "子砚")) == 1
end

-- 把字符串转成 JSON 字符串字面量（含引号）。
-- 注意：不能用 string.format("%q")——Lua 5.4 会把换行写成 "\"+真实换行（非法 JSON），
-- 5.3 用 \ 后跟十进制数字（同样非法）。这里逐字节手工转义，保证跨版本合法。
-- @return string json, boolean valid_utf8（false 时调用方可决定是否降级 base64）
local function jstr_ex(s)
  s = tostring(s == nil and "" or s)
  local utf8_ok = is_utf8()
  local out = { '"' }
  for i = 1, #s do
    local b = s:byte(i)
    local c = string.char(b)
    if c == '"' then
      out[#out + 1] = '\\"'
    elseif c == "\\" then
      out[#out + 1] = "\\\\"
    elseif c == "\n" then
      out[#out + 1] = "\\n"
    elseif c == "\r" then
      out[#out + 1] = "\\r"
    elseif c == "\t" then
      out[#out + 1] = "\\t"
    elseif b < 0x20 or b == 0x7F then
      out[#out + 1] = string.format("\\u%04X", b)
    elseif b >= 0x80 and not utf8_ok then
      -- 非 UTF-8 环境：把高位字节转义为 \u00XX，至少保持 JSON 可解析
      out[#out + 1] = string.format("\\u%04X", b)
    else
      out[#out + 1] = c
    end
  end
  out[#out + 1] = '"'
  return table.concat(out), utf8_ok
end

local function jstr(s)
  local body = jstr_ex(s)
  return body
end

local function trim(s)
  return (tostring(s or ""):gsub("%s+$", ""))
end


--- 统一命令执行正本：lua/modules/zy_shell.lua（2026-09-12 去重；原本地拷贝已删）
--- require 优先；embed/无 package.path 场景按安装路径 dofile 兜底。
local var_dir  -- 前向声明：var_dir 于路径解析区赋值，本文件多处使用

local ZS = (function()
  local ok, mod = pcall(require, "zy_shell")
  if ok and type(mod) == "table" and type(mod.run_capture) == "function" then return mod end
  local base = _G.ZIYAN_LUA or "/usr/lib/ziyan/lib/lua"
  for _, p in ipairs({ base .. "/modules/zy_shell.lua",
      "/var/jb/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
      "/usr/lib/ziyan/lib/lua/modules/zy_shell.lua" }) do
    local f = io.open(p, "r")
    if f then
      f:close()
      local ok2, m2 = pcall(dofile, p)
      if ok2 and type(m2) == "table" and type(m2.run_capture) == "function" then return m2 end
    end
  end
  return nil
end)()
assert(ZS, "zy_shell 加载失败（lua/modules/zy_shell.lua 缺失）")
local run_capture = ZS.run_capture

local function path_exists(path)
  -- 2026-09-17 性能修复：原实现无条件先起 shell（`test -e`）。设备实测起一次
  -- shell 87~94ms，而 report 路径上要判多次存在性 → 单次 report 累计 3.7~4.1 秒，
  -- 且全部落在脚本启动的同步路径上（on_process_start 触发 1~2 次 report）。
  --
  -- 实测确认（.101）：io.open 对【目录】也返回成功（seek 得 17376），
  -- 所以 io.open 不能用来区分文件/目录 —— 原注释这点是对的。
  -- 但 path_exists 只问「存在与否」，不区分类型：io.open 成功 ⇒ 路径存在，
  -- 这在本函数语义下完全成立。因此把 io.open 提到前面作为快路径，
  -- 只在 io.open 失败时（不存在，或权限不足打不开）才退回 shell 复核，
  -- 保留原有的权限边界语义。
  local f = io.open(path, "r")
  if f then
    f:close()
    return true
  end
  -- io.open 失败：可能不存在，也可能是存在但不可读（权限）。用 shell 复核。
  local out = run_capture(string.format("test -e '%s' && echo 1 || echo 0", path))
  if out then return trim(out) == "1" end
  return false
end

local function read_text(path)
  local f = io.open(path, "r")
  if not f then return nil end
  local body = f:read("*a")
  f:close()
  return body
end

local function write_text(path, body)
  local ok = pcall(function()
    local f = io.open(path, "w")
    if not f then return end
    f:write(body)
    f:close()
  end)
  return ok
end

local function mkdir_p(path)
  -- 2026-09-17 性能修复：原实现每轮先起 shell（`mkdir -p`）再探测，设备实测
  -- 起一次 shell 87~94ms。report 每次都调 mkdir_p → 启动路径上白付一次。
  -- 改为纯 Lua：先探测目录是否已可写（写 .probe 成功即已存在可用），
  -- 只有在不可写时才起 shell 建目录 —— 稳态下（目录已存在）零 shell。
  -- 保留原探测语义：以「能否写入 .probe」作为成功判据。
  local probe = io.open(path .. "/.probe", "w")
  if probe then
    probe:close()
    os.remove(path .. "/.probe")
    return true
  end
  run_capture(string.format("mkdir -p '%s'", path))
  probe = io.open(path .. "/.probe", "w")
  if probe then
    probe:close()
    os.remove(path .. "/.probe")
    return true
  end
  return false
end

---------------------------------------------------------------------------
-- 路径解析
---------------------------------------------------------------------------

local function root_dir()
  if type(_G.ZIYAN_ZYCV) == "string" and #_G.ZIYAN_ZYCV > 0 then
    return _G.ZIYAN_ZYCV
  end
  local p = "/private/var/mobile/Media/ZiYan/ZYCV"
  if io.open(p .. "/res", "r") then return p end
  local legacy = "/var/mobile/Media/ZiYan/ZYCV"
  if io.open(legacy .. "/res", "r") then return legacy end
  return p
end

function M.report_dir()
  return root_dir() .. "/res/错误报告"
end

var_dir = function()
  return _G.ZIYAN_VAR or "/usr/lib/ziyan/var"
end

---------------------------------------------------------------------------
-- 运行信息
---------------------------------------------------------------------------

local function now_iso(ts)
  return os.date("%Y-%m-%d %H:%M:%S", ts or os.time())
end

local function read_os_version()
  -- 直接读 plist（不依赖 shell；rootless 设备无 sysctl/plutil 也能拿到）
  local body = read_text("/System/Library/CoreServices/SystemVersion.plist")
  if body then
    local v = body:match("<key>ProductVersion</key>%s*<string>([^<]+)</string>")
    if v and #v > 0 then return v end
  end
  return nil
end

local function read_arch_hint()
  -- rootless/rootful 以 runtime scheme 标记为准（postinst 写入，root 与 mobile 都可读）
  local marker = read_text("/var/mobile/Library/Preferences/com.ziyan.ziyan.runtime_scheme")
  if marker then
    local scheme = trim(marker:match("^([^\n]*)") or "")
    if scheme == "rootless" then return "iphoneos-arm64", true end
    if scheme == "rootful" then return "iphoneos-arm", false end
  end
  if io.open("/var/jb/usr/lib/ziyan/var", "r") then return "iphoneos-arm64", true end
  return nil, false
end

local function device_info()
  local info = { model = "unknown", os = "unknown", arch = "unknown", rootless = false }

  -- 1) 纯文件来源（无 shell 依赖，rootless 也 100% 可用）
  local osv = read_os_version()
  if osv then info.os = "iOS " .. osv end
  local arch, rootless = read_arch_hint()
  if arch then
    info.arch = arch
    info.rootless = rootless and true or false
  end

  -- 2) 引擎 Device 模块（App/embed 上下文）
  pcall(function()
    local d = _G.Zy and _G.Zy.Device
    if type(d) == "table" and type(d.profile) == "function" then
      local p = d.profile()
      if type(p) == "table" then
        if p.model and tostring(p.model) ~= "" then info.model = tostring(p.model) end
        if p.os and tostring(p.os) ~= "" then info.os = tostring(p.os) end
        if p.arch and tostring(p.arch) ~= "" then info.arch = tostring(p.arch) end
        info.rootless = p.rootless == true
        info.native_w = p.native_w
        info.native_h = p.native_h
        info.orient = p.orient
        info.cpu = p.cpu
        info.cpu_n = p.cpu_n
      end
    end
  end)

  -- 3) 机型：缓存 → sysctl（不可用则保持 unknown，绝不再写坏缓存）
  local marker = var_dir() .. "/.ziyan_error_reporter_device_v2"
  local cached = read_text(marker)
  if cached and #cached > 0 and info.model == "unknown" then
    local model = cached:match("^([^\n]*)")
    if model and #model > 0 and model ~= "unknown" then info.model = model end
  end
  if info.model == "unknown" then
    pcall(function()
      local body = run_capture("sysctl -n hw.machine 2>/dev/null; sysctl -n hw.model 2>/dev/null")
      if not body then return end
      local machine, model = body:match("([^\n]*)\n([^\n]*)")
      if model and #trim(model) > 0 and trim(model) ~= "unknown" then
        info.model = trim(model)
      elseif machine and #trim(machine) > 0 then
        info.model = trim(machine)
      end
    end)
  end

  -- 只在拿到真实机型时写缓存（避免把 unknown 固化）
  if info.model ~= "unknown" then
    write_text(marker, info.model .. "\n" .. info.os .. "\n" .. info.arch .. "\n")
  end
  return info
end

local function version_info()
  local v = { ziyan = "unknown", script = "unknown", commit = "unknown" }
  if type(_G.ZIYAN_VERSION) == "string" and #_G.ZIYAN_VERSION > 0 then
    v.ziyan = _G.ZIYAN_VERSION
  end
  if v.ziyan == "unknown" then
    local body = read_text(var_dir() .. "/.ziyan_version")
    if body and #trim(body) > 0 then v.ziyan = trim(body) end
  end
  -- 2026-09-17 性能修复 + 正确性修复：dpkg-query 起 shell，实测单次 ~90ms。
  -- 原实现【每次 report 都无条件起 shell】且无缓存。
  --
  -- 实测还发现一个真实缺陷：设备上装的是【拆分包】com.ziyan.ziyan-rootful /
  -- -rootless，而原代码只查统一名 com.ziyan.ziyan → 查询恒为空，于是
  -- 每次都白跑一次 shell（90ms）却拿不到版本。这里把三个包名都试一遍，
  -- 且把结果落盘缓存（版本在同一安装期内不变）。
  -- 缓存必须落盘：embed 每轮重建 VM，_G 缓存会全丢（实测无效）。
  local vcache = var_dir() .. "/.ziyan_er_ver_cache"
  local cached_ver = read_text(vcache)
  if cached_ver and #trim(cached_ver) > 0 then
    v.ziyan = trim(cached_ver)
  else
    pcall(function()
      for _, pkg in ipairs({
        "com.ziyan.ziyan", "com.ziyan.ziyan-rootful", "com.ziyan.ziyan-rootless",
      }) do
        local out = run_capture(string.format(
          "dpkg-query -W -f='${Version}' %s 2>/dev/null", pkg))
        if out then
          local body = trim(out)
          if #body > 0 then
            v.ziyan = body
            write_text(vcache, body .. "\n")
            break
          end
        end
      end
    end)
  end
  if v.ziyan == "unknown" then
    local engine = _G.Zy and _G.Zy.version
    if engine then v.ziyan = "engine-" .. tostring(engine) end
  end
  return v
end

local function runtime_info()
  local r = {
    process = "lua",
    pid = "unknown",
    rss_mb = -1,
    uptime_sec = -1,
    loop = 0,
  }
  pcall(function()
    local body = read_text("/proc/self/status") or ""
    local pid = body:match("^Pid:%s*(%d+)")
    if pid then r.pid = tonumber(pid) end
    local kb = body:match("VmRSS:%s*(%d+)")
    if kb then r.rss_mb = math.floor(tonumber(kb) / 1024) end
  end)
  if r.pid == "unknown" then
    -- iOS 无 /proc：embed 上下文用宿主写入的 pid 文件（framecap/lua_run）
    for _, f in ipairs({ var_dir() .. "/.ziyan_lua_run.pid", var_dir() .. "/.ziyan_framecap_alive" }) do
      local body = read_text(f)
      if body then
        local pid = tonumber(trim(body:match("^([^\n]*)") or ""))
        if pid and pid > 1 then r.pid = pid break end
      end
    end
    if r.pid ~= "unknown" then r.process = _G.ZIYAN_EMBED and "framecap-embed" or "lua" end
  end
  pcall(function()
    if _G.ErrorReporter and _G.ErrorReporter._start_ts then
      r.uptime_sec = os.time() - _G.ErrorReporter._start_ts
    elseif M._start_ts then
      r.uptime_sec = os.time() - M._start_ts
    end
  end)
  pcall(function()
    if _G.SafeExecutor and type(_G.SafeExecutor.state) == "table" then
      r.loop = tonumber(_G.SafeExecutor.state.loop_count) or 0
    elseif _G.HealthMonitor then
      r.loop = tonumber(_G.HealthMonitor.loop_count) or 0
    end
  end)
  return r
end

local function system_diagnostics()
  -- 2026-09-17 性能修复：本函数跑 3 条 shell 命令，其中 `ps -axo pid,comm`
  -- 是【全进程表扫描】—— 在 2 核过载设备上实测单次可达 1~2 秒。而 report
  -- 每次都会调用它，于是每次 on_process_start（触发 1~2 次 report）都要付
  -- 这个代价，且全部落在脚本启动的同步路径上。
  --
  -- 语义权衡：诊断信息是【排障用】的附加上下文，不是报告主体（主体是
  -- 错误类型/消息/堆栈/设备/版本）。
  -- 缓存必须【落盘】：embed 每轮重建 VM，_G 缓存全丢（实测用 _G 缓存无效）。
  -- 用 60s 时间窗落盘缓存：真实错误报告仍带诊断（最多旧 60 秒），
  -- 但连续启动不重复付昂贵的 ps 扫描。置 .ziyan_er_diag_every 关闭缓存。
  local d = {}
  local diag_path = var_dir() .. "/.ziyan_er_diag_cache"
  local diag_every = io.open(var_dir() .. "/.ziyan_er_diag_every", "r")
  if diag_every then
    diag_every:close()
  else
    local body = read_text(diag_path)
    if body then
      local ts, shell = body:match("^(%d+)\n(.*)$")
      if ts and (os.time() - tonumber(ts)) < 60 then
        d.shell = shell
        return d
      end
    end
  end
  pcall(function()
    local body = run_capture(
      "echo \"--df--\"; df -k / /private/var 2>/dev/null | head -4; "
        .. "echo \"--uptime--\"; uptime 2>/dev/null; "
        .. "echo \"--sb--\"; ps -axo pid,comm 2>/dev/null | grep -E 'SpringBoard$| ziYan|ziyan' | head -8")
    if body then
      d.shell = body:sub(1, 4000)
      write_text(diag_path, tostring(os.time()) .. "\n" .. d.shell)
    end
  end)
  return d
end

---------------------------------------------------------------------------
-- 事件写入
---------------------------------------------------------------------------

local _seq = 0

local function make_event_id(err_type)
  _seq = _seq + 1
  local ts = os.time()
  local tag = tostring(err_type or "error"):gsub("[^%w_%-]", "_"):sub(1, 24)
  return string.format("zye_%d_%02d_%s", ts, _seq % 100, tag)
end

function M.current_script(path)
  if path ~= nil and #tostring(path) > 0 then
    M._script_path = tostring(path)
  end
  return M._script_path or "unknown"
end

local function script_info()
  local path = M._script_path or "unknown"
  local body = nil
  if path ~= "unknown" then
    body = read_text(path)
  end
  return {
    path = path,
    name = path ~= "unknown" and (path:match("([^/]+)$") or path) or "unknown",
    size = body and #body or -1,
    content = body and body:sub(1, 200000) or nil,
  }
end

--- 写一份错误报告。
--- @param err_type string 事件类型
--- @param message string 错误内容
--- @param extra table|nil 可选：{ phase=, timeout_ms=, stack=, module=, note= }
--- @return string|nil event_id, string|nil dir
function M.report(err_type, message, extra)
  extra = type(extra) == "table" and extra or {}
  local event_id = make_event_id(err_type)
  local base = M.report_dir()
  local dir = base .. "/" .. event_id
  local ok_dir = mkdir_p(dir)
  if not ok_dir then
    -- 目录创建失败退化为单文件，保证不丢证据
    dir = base
  end

  local ts = os.time()
  local dev = device_info()
  local ver = version_info()
  local rt = runtime_info()
  local scr = script_info()
  local phase = tostring(extra.phase or "")

  local report = {
    event_id = event_id,
    time = now_iso(ts),
    time_unix = ts,
    type = tostring(err_type or "unknown"),
    phase = phase,
    message = tostring(message or ""):sub(1, 4000),
    stack = extra.stack and tostring(extra.stack):sub(1, 8000) or nil,
    module = extra.module and tostring(extra.module) or nil,
    note = extra.note and tostring(extra.note) or nil,
    timeout_ms = extra.timeout_ms,
    device = {
      model = dev.model,
      os = dev.os,
      arch = dev.arch,
      rootless = dev.rootless,
      native_w = dev.native_w,
      native_h = dev.native_h,
      orient = dev.orient,
      cpu = dev.cpu,
      cpu_n = dev.cpu_n,
    },
    version = {
      ziyan = ver.ziyan,
      script = ver.script,
      commit = ver.commit,
      engine = _G.Zy and _G.Zy.version or "unknown",
    },
    script = {
      path = scr.path,
      name = scr.name,
      size = scr.size,
    },
    runtime = {
      process = rt.process,
      pid = rt.pid,
      rss_mb = rt.rss_mb,
      uptime_sec = rt.uptime_sec,
      loop = rt.loop,
      lua = _VERSION,
    },
    diagnostics = system_diagnostics(),
  }

  local json = {}
  json[#json + 1] = "{"
  json[#json + 1] = string.format('"event_id":%s,', jstr(report.event_id))
  json[#json + 1] = string.format('"time":%s,', jstr(report.time))
  json[#json + 1] = string.format('"time_unix":%d,', report.time_unix)
  json[#json + 1] = string.format('"type":%s,', jstr(report.type))
  json[#json + 1] = string.format('"phase":%s,', jstr(report.phase))
  json[#json + 1] = string.format('"message":%s,', jstr(report.message))
  if report.stack then
    json[#json + 1] = string.format('"stack":%s,', jstr(report.stack))
  end
  if report.module then
    json[#json + 1] = string.format('"module":%s,', jstr(report.module))
  end
  if report.note then
    json[#json + 1] = string.format('"note":%s,', jstr(report.note))
  end
  if report.timeout_ms then
    json[#json + 1] = string.format('"timeout_ms":%s,', tostring(tonumber(report.timeout_ms) or 0))
  end
  json[#json + 1] = string.format(
    '"device":{"model":%s,"os":%s,"arch":%s,"rootless":%s,"native_w":%s,"native_h":%s,"orient":%s},',
    jstr(report.device.model), jstr(report.device.os), jstr(report.device.arch),
    report.device.rootless and "true" or "false",
    tostring(tonumber(report.device.native_w) or 0), tostring(tonumber(report.device.native_h) or 0),
    tostring(tonumber(report.device.orient) or 0))
  json[#json + 1] = string.format(
    '"version":{"ziyan":%s,"script":%s,"commit":%s,"engine":%s},',
    jstr(report.version.ziyan), jstr(report.version.script), jstr(report.version.commit),
    jstr(report.version.engine))
  json[#json + 1] = string.format(
    '"script":{"path":%s,"name":%s,"size":%d},',
    jstr(report.script.path), jstr(report.script.name), report.script.size)
  json[#json + 1] = string.format(
    '"runtime":{"process":%s,"pid":%s,"rss_mb":%s,"uptime_sec":%s,"loop":%s,"lua":%s},',
    jstr(report.runtime.process), tostring(tonumber(report.runtime.pid) or 0),
    tostring(tonumber(report.runtime.rss_mb) or -1),
    tostring(tonumber(report.runtime.uptime_sec) or -1),
    tostring(tonumber(report.runtime.loop) or 0), jstr(report.runtime.lua))
  json[#json + 1] = string.format('"diagnostics":{"shell":%s}',
    jstr(report.diagnostics.shell or ""))
  json[#json + 1] = "}\n"

  local final = dir .. "/report.json"
  if not ok_dir then
    final = base .. "/" .. event_id .. ".json"
  end
  write_text(final, table.concat(json))

  if ok_dir then
    local ctx = {
      "事件ID: " .. event_id,
      "时间: " .. report.time,
      "类型: " .. report.type,
      "阶段: " .. (phase ~= "" and phase or "(无)"),
      "设备: " .. report.device.model .. " / " .. report.device.os .. " / " .. report.device.arch,
      "ZiYan: " .. report.version.ziyan .. " (engine " .. tostring(report.version.engine) .. ")",
      "业务脚本: " .. report.script.path,
      "进程: pid=" .. tostring(report.runtime.pid) .. " rss=" .. tostring(report.runtime.rss_mb) .. "MB"
        .. " loop=" .. tostring(report.runtime.loop) .. " uptime=" .. tostring(report.runtime.uptime_sec) .. "s",
      "错误内容: " .. report.message,
    }
    if report.stack then ctx[#ctx + 1] = "堆栈: " .. report.stack end
    ctx[#ctx + 1] = ""
    ctx[#ctx + 1] = "---- 系统诊断 ----"
    ctx[#ctx + 1] = tostring(report.diagnostics.shell or "")
    write_text(dir .. "/context.txt", table.concat(ctx, "\n") .. "\n")
    if scr.content then
      write_text(dir .. "/script.txt", scr.content)
    end
  end

  -- Expose the handoff result; retention checks the durable copy again.
  local queued, queue_error = false, "queue_unavailable"
  local q = _G.OfflineQueue
  if type(q) == "table" and type(q.enqueue) == "function" then
    local called, accepted, reason = pcall(q.enqueue, event_id, final)
    queued = called and accepted == true
    if queued then queue_error = nil
    else queue_error = tostring(reason or (not called and accepted) or "queue_commit_failed") end
  end
  M._last_enqueue = {event_id=event_id, ok=queued, error=queue_error}

  -- FTP 独立适配层只复用报告文件，不读取或改写 HTTP .upload_spool。
  local ftp_queued, ftp_error = false, "ftp_queue_unavailable"
  local ftp = _G.FtpErrorUploader
  if type(ftp) == "table" and type(ftp.enqueue) == "function" then
    local called, accepted, reason = pcall(ftp.enqueue, event_id, final)
    ftp_queued = called and accepted == true
    if ftp_queued then ftp_error = nil
    else ftp_error = tostring(reason or (not called and accepted) or "ftp_queue_commit_failed") end
  end
  M._last_ftp_enqueue = {event_id=event_id, ok=ftp_queued, error=ftp_error}

  -- install() already purges during VM startup; avoid scanning the same reports twice.
  local last_purge = M._last_purge
  if not last_purge or os.time() - (tonumber(last_purge.ts) or 0) >= 60 then
    pcall(M.purge)
  end
  return event_id, final, {
    queued=queued,
    queue_error=queue_error,
    ftp_queued=ftp_queued,
    ftp_queue_error=ftp_error,
  }
end

---------------------------------------------------------------------------
-- 脚本错误快捷入口（pcall 的 err 可能带 "file:line: msg" 前缀）
---------------------------------------------------------------------------

function M.handle(script_path, err, extra)
  if script_path then M.current_script(script_path) end
  local msg = tostring(err or "unknown")
  local stack = nil
  local cut = msg:find("stack traceback:", 1, true)
  if cut then
    stack = msg:sub(cut)
    msg = msg:sub(1, cut - 1)
  end
  local exact = type(extra) == "table" and extra or {}
  if stack then exact.stack = stack end
  local event_id, path = M.report("script_error", msg, exact)
  return event_id, path
end

---------------------------------------------------------------------------
-- 生命周期事件（冷启动 / SB 重启 / 异常退出）——由宿主或守护调用
---------------------------------------------------------------------------

local function var_num(name)
  local body = read_text(var_dir() .. "/" .. name)
  if not body then return nil end
  return tonumber(trim(body))
end

--- 进程启动时调用：与上次记录比 SB PID / 上次退出标记，判定冷启动或 SB 重启
function M.on_process_start(reason)
  local sb = var_num(".ziyan_sb_pid")
  local last_exit = read_text(var_dir() .. "/.ziyan_last_exit")
  local last_ts = var_num(".ziyan_last_exit_ts")
  local prev_sb = var_num(".ziyan_error_reporter_last_sb")
  local running = read_text(var_dir() .. "/.ziyan_running")
  local kind, note = "cold_start", tostring(reason or "")
  if sb and prev_sb and sb ~= prev_sb then
    kind = "sb_restart"
    note = string.format("SB %s -> %s", tostring(prev_sb), tostring(sb))
  end
  local exact = { module = "ErrorReporter" }
  if last_exit then
    local seen = last_ts and (os.time() - last_ts) or -1
    exact.note = "last_exit=" .. trim(last_exit) .. " age=" .. tostring(seen) .. "s"
  end
  if running and #trim(running) > 0 then
    -- 上次运行标记仍在 → 上次进程非正常结束（崩溃/被强杀）
    exact.note = (exact.note and (exact.note .. " | ") or "")
      .. "leftover_running=" .. trim(running)
    M.report("abnormal_exit", "上次脚本进程未正常结束（运行标记残留）", exact)
    pcall(os.remove, var_dir() .. "/.ziyan_running")
  end
  -- 2026-09-17 修复【设计缺陷】：VM 重建被误报成「进程冷启动」。
  --
  -- 实测证据（.53，framecap 进程 Sep 16 18:48 启动、连续运行 16+ 小时）：
  -- 期间 spool 累积 1601 条报告，抽样 400/400 全是 cold_start，
  -- 速率 21 条/小时 ≈ 500 条/天，占盘 13MB。
  --
  -- 根因链：ziyan_te_boot 每轮脚本启动都跑（runner 每轮 luaL_loadfile），
  -- 于是每轮都调 on_process_start → report("cold_start")。但 embed 每轮
  -- 【新建 Lua VM】而 framecap 进程并未重启 —— 进程内的「第 N 个 VM」
  -- 被当成了「第 N 次进程冷启动」。
  --
  -- 判定依据取 .ziyan_embed_alive 的 pid（C 层 WriteEmbedAlive 在 te_boot
  -- 之前就已写入，含 pid= 与 vm_gen=）：
  --   · 同 pid → 同一宿主进程内的 VM 重建，不是需要上报的异常事件，
  --     只在内存里记一条 vm_rebuild 诊断，不写报告、不入队。
  --   · pid 变化 → 真进程重启，正常记 cold_start。
  -- 既保留「真冷启动」证据，又消除每轮脚本的无效报告洪流。
  local aliveTxt = read_text(var_dir() .. "/.ziyan_embed_alive") or ""
  local hostPid = aliveTxt:match("pid=(%d+)")
  if hostPid and kind == "cold_start" then
    local keyPath = var_dir() .. "/.ziyan_er_last_host_pid"
    local prevPid = trim(read_text(keyPath) or "")
    if prevPid == hostPid then
      M._last_vm_rebuild = { ts = os.time(), pid = hostPid }
      -- 仍要维护 SB 去重旗标与停止旗标，否则 SB 重启/停脚本会重复报
      write_text(var_dir() .. "/.ziyan_error_reporter_last_sb", tostring(sb or 0))
      pcall(os.remove, var_dir() .. "/" .. (M.STOP_GUARD or ".ziyan_error_reporter_stop_done"))
      return true
    end
    write_text(keyPath, hostPid .. "\n")
  end
  M.report(kind, "进程启动: " .. note, exact)
  -- 停止去重旗标：新会话开始即可再次记录停止事件
  pcall(os.remove, var_dir() .. "/" .. (M.STOP_GUARD or ".ziyan_error_reporter_stop_done"))
  write_text(var_dir() .. "/.ziyan_error_reporter_last_sb", tostring(sb or 0))
  return true
end

--- 宿主/守护在脚本被强制停止或异常退出时调用
function M.on_stop(why, extra)
  local exact = type(extra) == "table" and extra or {}
  exact.module = exact.module or "control"
  return M.report("stop", tostring(why or "user_stop"), exact)
end

---------------------------------------------------------------------------
-- 保留期清理（默认 3 天；未到期绝不删除）
---------------------------------------------------------------------------

function M.retention_days()
  return tonumber(M._retention_days) or 3
end

function M.set_retention(days)
  days = tonumber(days)
  if days and days >= 1 then M._retention_days = days end
  return M.retention_days()
end

--- 扫描报告目录，删除创建时间早于保留期的报告目录/文件。
--- @return number deleted, number kept
function M.purge(retention_days)
  local days = tonumber(retention_days) or M.retention_days()
  local cutoff = os.time() - days * 86400
  local base = M.report_dir()
  local deleted, kept = 0, 0
  local log_lines = {}
  local ok = pcall(function()
    local listing = run_capture(string.format("ls -1 '%s' 2>/dev/null", base))
    if not listing then return end
    for name in listing:gmatch("[^\n]+") do
      if name ~= ".probe" and name ~= "_cleanup.log" and not name:match("^%.") then
        local path = base .. "/" .. name
        local ts = nil
        -- 优先取 report.json 内的 time_unix；退化到目录 mtime
        local body = read_text(path .. "/report.json")
        if body then
          ts = tonumber(body:match('"time_unix":(%d+)'))
        end
        if not ts then
          local id_ts = tonumber(name:match("^zye_(%d+)_"))
          if id_ts then ts = id_ts - (id_ts % 1) end
        end
        if not ts then
          local st_out = run_capture(string.format("stat -f %%m '%s' 2>/dev/null", path))
          if st_out then ts = tonumber(trim(st_out)) end
        end
        if ts and ts > 0 then
          local handed_off = false
          local queue = _G.OfflineQueue
          if type(queue) == "table" and type(queue.is_durable) == "function" then
            local checked, durable = pcall(queue.is_durable, name, path .. "/report.json")
            handed_off = checked and durable == true
          end
          if ts < cutoff and handed_off then
            pcall(function()
              os.execute(SH_PATH .. string.format("rm -rf '%s' 2>/dev/null", path))
            end)
            if not path_exists(path) then
              deleted = deleted + 1
              log_lines[#log_lines + 1] = string.format(
                "%s deleted %s (age=%dd)", now_iso(), name, math.floor((os.time() - ts) / 86400))
            else
              kept = kept + 1
            end
          else
            kept = kept + 1
          end
        else
          kept = kept + 1
        end
      end
    end
  end)
  if not ok then
    return 0, 0
  end
  if deleted > 0 then
    local log = io.open(base .. "/_cleanup.log", "a")
    if log then
      log:write(table.concat(log_lines, "\n") .. "\n")
      log:close()
    end
  end
  M._last_purge = { ts = os.time(), deleted = deleted, kept = kept, retention_days = days }

  -- 2026-09-17 修复：OfflineQueue.cleanup_sent 此前【零调用方】。
  -- OfflineQueue.lua 的注释写明「（由 ErrorReporter.purge 调用）」，但 purge 里
  -- 只有 is_durable 判定，从未调用它 —— 于是 status=="sent" 的条目永远留在 spool。
  -- 实测 .101：upload_spool 135 条里 34 条是已发送的（sent），加 ftp 102 条，
  -- 既占磁盘又拖慢每次 flush（flush 要遍历全部条目做 recover_state）。
  -- cleanup_sent 本身可用：实测 560ms 清掉 17 条。
  --
  -- 节流：purge 在 ErrorReporter.install() 里每次启动都跑，而积压清理不需要
  -- 每轮都做（sent 条目是历史残留，不是热数据）。用落盘时间闸 6 小时一次，
  -- 避免给它每轮增加 ~0.5s。首次（无闸文件）立即执行一次，把现存积压清掉。
  local CLEAN_GATE = var_dir() .. "/.ziyan_oq_clean_gate"
  local nowT = os.time()
  local lastClean = 0
  local gf2 = io.open(CLEAN_GATE, "r")
  if gf2 then lastClean = tonumber(gf2:read("*l")) or 0; gf2:close() end
  if lastClean <= 0 or (nowT - lastClean) >= 6 * 3600 then
    local q = _G.OfflineQueue
    if type(q) == "table" and type(q.cleanup_sent) == "function" then
      pcall(function()
        local removed = q.cleanup_sent(3 * 86400)
        M._last_cleanup_sent = { ts = nowT, removed = tonumber(removed) or 0 }
        local w2 = io.open(CLEAN_GATE, "w")
        if w2 then w2:write(tostring(nowT)); w2:close() end
      end)
    end
    -- FTP 侧同样清理（本函数是本轮新加的：FtpErrorUploader 此前完全没有
    -- cleanup_sent，sent 条目会无限累积）。与 HTTP 共用同一时间闸。
    local fq = _G.FtpErrorUploader
    if type(fq) == "table" and type(fq.cleanup_sent) == "function" then
      pcall(function()
        local removedF = fq.cleanup_sent(3 * 86400)
        M._last_cleanup_ftp = { ts = nowT, removed = tonumber(removedF) or 0 }
      end)
    end
  end
  return deleted, kept
end

function M.list()
  local ids = {}
  pcall(function()
    local listing = run_capture(string.format("ls -1 '%s' 2>/dev/null", M.report_dir()))
    if not listing then return end
    for name in listing:gmatch("[^\n]+") do
      if name:match("^zye_") then ids[#ids + 1] = name end
    end
  end)
  return ids
end

---------------------------------------------------------------------------
-- 安装
---------------------------------------------------------------------------

function M.install()
  _G.ErrorReporter = M
  _G.__ZIYAN_ERROR_REPORTER = M.version
  M._start_ts = M._start_ts or os.time()
  M._script_path = M._script_path or "unknown"
  pcall(function() M.purge() end)
  return M
end

function M.uninstall()
  if _G.ErrorReporter == M then _G.ErrorReporter = nil end
  _G.__ZIYAN_ERROR_REPORTER = nil
  return true
end

return M
