--[[ FtpErrorUploader — 错误报告普通 FTP 上传适配层。
  使用 ErrorReporter 的同一报告根目录，独立维护 .ftp_upload_spool；
  不读取或修改 OfflineQueue 的 .upload_spool HTTP 状态。
]]

local M = { name = "FtpErrorUploader", version = "1.1.0" }

M.PENDING_CAP_BYTES = 5 * 1024 * 1024
M.COPY_CHUNK_BYTES = 64 * 1024
M.LARGE_FILE_BYTES = 1024 * 1024
M.BASE_RETRY_SEC = 30
M.MAX_RETRY_SEC = 3600
M.BATCH = 4
-- 2026-09-16：py_cv.lua 的 ftplib 通道已加 REST 断点续传（.61 真机验证：
-- 远端已有 8192/16384 时仅补传剩余 8192 字节）。续传能力取决于实际走哪条
-- 传输通道（ftplib 支持 REST；curl -T 分支为整传覆盖），因此按次记录
-- 观测结果，而不是给一个全局常量冒充「续传已支持」。
M.RESUME_SUPPORTED = false
M.LARGE_FILE_VERDICT = "PARTIAL"
M.RESUME_VERDICT = "BLOCKED"

--- 错误码枚举（需求书 §三.10：网络失败/认证失败/远端空间不足/分片缺失须返回明确错误码）
--- 纯函数，便于单测；未识别的原因归入 FTP_ERR_UNKNOWN 并保留原文。
M.ERR_CODES = {
  "FTP_ERR_CONFIG",         -- 配置缺失/非法
  "FTP_ERR_NETWORK",        -- 连接超时、无法解析主机、原语缺失
  "FTP_ERR_AUTH",           -- 530 / login incorrect / access denied
  "FTP_ERR_NOSPACE",        -- 552 / quota / no space
  "FTP_ERR_CHUNK_MISSING",  -- 远端尺寸取不到、本地分片缺失
  "FTP_ERR_SIZE_MISMATCH",  -- 远端大小与本地不一致
  "FTP_ERR_HASH_MISMATCH",  -- sha256 sidecar 不一致
  "FTP_ERR_STATE",          -- 本地状态提交失败
  "FTP_ERR_UNKNOWN",
}

local function classify(reason)
  local r = tostring(reason or ""):lower()
  if r == "" then return "FTP_ERR_UNKNOWN" end
  if r:find("config_missing", 1, true) or r:find("invalid_event_id", 1, true) then
    return "FTP_ERR_CONFIG"
  end
  if r:find("hash", 1, true) or r:find("sha256", 1, true) or r:find("checksum", 1, true) then
    return "FTP_ERR_HASH_MISMATCH"
  end
  if r:find("530", 1, true) or r:find("login incorrect", 1, true)
      or r:find("access denied", 1, true) or r:find("auth", 1, true) then
    return "FTP_ERR_AUTH"
  end
  if r:find("552", 1, true) or r:find("quota", 1, true)
      or r:find("no space", 1, true) or r:find("disk full", 1, true) then
    return "FTP_ERR_NOSPACE"
  end
  if r:find("size_mismatch", 1, true) then return "FTP_ERR_SIZE_MISMATCH" end
  if r:find("no_remote_size", 1, true) or r:find("remote_size_unavailable", 1, true)
      or r:find("spool_missing", 1, true) or r:find("missing", 1, true) then
    return "FTP_ERR_CHUNK_MISSING"
  end
  if r:find("state_", 1, true) or r:find("commit_failed", 1, true) then
    return "FTP_ERR_STATE"
  end
  if r:find("timeout", 1, true) or r:find("timed out", 1, true)
      or r:find("could not resolve", 1, true) or r:find("connection", 1, true)
      or r:find("network", 1, true) or r:find("ftp_primitive_missing", 1, true)
      or r:find("ftp_fail", 1, true) or r:find("ftp_upload_failed", 1, true)
      or r:find("capability_missing", 1, true) then
    return "FTP_ERR_NETWORK"
  end
  return "FTP_ERR_UNKNOWN"
end
M.classify_error = classify

local ZS = (function()
  local ok, mod = pcall(require, "zy_shell")
  if ok and type(mod) == "table" and type(mod.run_capture) == "function" then return mod end
  local base = _G.ZIYAN_LUA or "/usr/lib/ziyan/lib/lua"
  for _, path in ipairs({
    base .. "/modules/zy_shell.lua",
    "/var/jb/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
    "/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
  }) do
    local f = io.open(path, "r")
    if f then
      f:close()
      local loaded, candidate = pcall(dofile, path)
      if loaded and type(candidate) == "table"
          and type(candidate.run_capture) == "function" then
        return candidate
      end
    end
  end
  return nil
end)()
assert(ZS, "zy_shell 加载失败（lua/modules/zy_shell.lua 缺失）")
local run_capture = ZS.run_capture

local function root()
  if type(_G.ZIYAN_ZYCV) == "string" and _G.ZIYAN_ZYCV ~= "" then
    return _G.ZIYAN_ZYCV
  end
  if io.open("/private/var/mobile/Media/ZiYan/ZYCV/res", "r") then
    return "/private/var/mobile/Media/ZiYan/ZYCV"
  end
  return "/var/mobile/Media/ZiYan/ZYCV"
end

local function valid_event_id(event_id)
  return type(event_id) == "string" and #event_id <= 200
      and event_id:match("^zye_[%w_%-]+$") ~= nil
end

--- 设备唯一 ID（需求书 §三.4：远端文件名 = 设备唯一 ID + 事件 ID）。
---
--- **必须用硬件 UUID，不能用 ErrorReporter 的机型 marker。**
--- 2026-09-16 真机实测（.101 与 .61）：
---   .101 marker 首行 = "iOS-640x1136@2"
---   .61  marker 首行 = "iOS-640x1136@2"   ← 两台不同设备完全相同
--- 该 marker 记的是「机型+分辨率」（供 ErrorReporter 显示用），不是唯一 ID；
--- 用它做前缀会让同型号设备互相覆盖远端文件。故改为只取 IOPlatformUUID。
---
--- 来源顺序：
---   1) var_dir()/.ziyan_ftp_device_uid 缓存（首次取到后落盘，避免每次起 shell）
---   2) ioreg IOPlatformUUID（与 Device.getDeviceID 同源）
---   3) 回退 "unknown"
--- 结果做 [%w%-] 白名单净化后才允许拼入远端路径（防路径注入）。
--- 注意：不得依赖 grep/awk —— .61/.53 rootless 实测 awk 缺失，既有
--- compat_impl.device.getDeviceID 正是因此恒退化为机型名。这里直接在 Lua 侧解析。
local function device_uid()
  local vd = _G.ZIYAN_VAR or "/usr/lib/ziyan/var"
  local cache = vd .. "/.ziyan_ftp_device_uid"
  local f = io.open(cache, "r")
  if f then
    local cached = (f:read("*l") or ""):gsub("[^%w%-]", "")
    f:close()
    if #cached >= 8 and cached ~= "unknown" then return cached:sub(1, 64) end
  end

  local raw = nil
  local out = run_capture("ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null")
  -- ioreg 行形如：      "IOPlatformUUID" = "6E6D2E4D-81D4-..."
  -- 必须取「= 右侧带连字符的 UUID」，否则会误取左侧键名 IOPlatformUUID。
  if type(out) == "string" then
    raw = out:match('"IOPlatformUUID"%s*=%s*"([%x%-]+)"')
  end

  local cleaned = tostring(raw or ""):gsub("[^%w%-]", "")
  -- 键名本身也会被净化成合法字符，必须显式排除；
  -- 同时要求含连字符或足够长，避免把机型串当 UUID。
  local looks_like_uuid = cleaned:find("%-") ~= nil and #cleaned >= 16
  if not looks_like_uuid or cleaned == "IOPlatformUUID" then
    cleaned = "unknown"
  end
  cleaned = cleaned:sub(1, 64)

  -- 只在拿到真 UUID 时写缓存（避免把 unknown 固化 —— ErrorReporter 同款纪律）
  if cleaned ~= "unknown" then
    local h = io.open(cache, "w")
    if h then h:write(cleaned .. "\n"); h:close() end
  end
  return cleaned
end
M.device_uid = device_uid

local function trim(value)
  return (tostring(value or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

local function mkdir_p(path)
  run_capture(string.format("mkdir -p '%s'", path))
  local probe = io.open(path .. "/.probe", "w")
  if not probe then return false end
  probe:close()
  os.remove(path .. "/.probe")
  return true
end

local function file_size(path)
  local f = io.open(path, "rb")
  if not f then return nil end
  local size = f:seek("end")
  f:close()
  return tonumber(size)
end

--- sha256（需求书 §三.7 sidecar 校验用）。
--- 复用设备侧既有三路兜底，与 HotUpdate.shasum 同源；全部不可用时返回 nil，
--- 调用方必须如实跳过 sidecar 而不是伪造校验通过。
local function sha256_of(path)
  local out = run_capture(string.format(
    "sha256sum '%s' 2>/dev/null || shasum -a 256 '%s' 2>/dev/null "
      .. "|| openssl dgst -sha256 '%s' 2>/dev/null", path, path, path))
  if type(out) ~= "string" then return nil end
  local hash = out:match("(%x+)")
  if not hash or #hash ~= 64 then hash = out:match("=%s*(%x+)") end
  if hash and #hash == 64 then return hash:lower() end
  return nil
end

local function copy_file_chunked(src, dst)
  local input, open_error = io.open(src, "rb")
  if not input then return false, open_error or "source_open_failed" end
  local tmp = dst .. ".tmp"
  local output, output_error = io.open(tmp, "wb")
  if not output then
    input:close()
    return false, output_error or "target_open_failed"
  end
  local ok, reason = true, nil
  while true do
    local chunk = input:read(M.COPY_CHUNK_BYTES)
    if not chunk then break end
    if not output:write(chunk) then
      ok, reason = false, "target_write_failed"
      break
    end
  end
  local input_closed = input:close()
  local output_closed = output:close()
  if not input_closed or not output_closed then
    ok, reason = false, reason or "copy_close_failed"
  end
  if ok then
    local renamed, rename_error = os.rename(tmp, dst)
    if not renamed then ok, reason = false, rename_error or "copy_rename_failed" end
  end
  os.remove(tmp)
  return ok, reason
end

local function write_text(path, body)
  local tmp = path .. ".tmp"
  local f, open_error = io.open(tmp, "wb")
  if not f then return false, open_error or "state_open_failed" end
  local wrote, write_error = f:write(body)
  local closed, close_error = f:close()
  if not wrote or not closed then
    os.remove(tmp)
    return false, write_error or close_error or "state_write_failed"
  end
  local renamed, rename_error = os.rename(tmp, path)
  os.remove(tmp)
  return renamed and true or false, rename_error
end

local function append_audit(action, event_id, size, detail)
  mkdir_p(M.spool_dir())
  local f = io.open(M.audit_path(), "a")
  if not f then return false end
  f:write(string.format(
    "%d %s event_id=%s size=%d detail=%s\n",
    os.time(), tostring(action), tostring(event_id), tonumber(size) or 0,
    tostring(detail or ""):gsub("[\r\n]", " "):sub(1, 200)))
  return f:close() and true or false
end

local function list_dir(path)
  local names = {}
  local listing = run_capture(string.format("ls -1 '%s'", path))
  if listing then
    for name in listing:gmatch("[^\n]+") do names[#names + 1] = name end
  end
  return names
end

local function remove_tree(path)
  run_capture(string.format("rm -rf '%s'", path))
  return io.open(path, "r") == nil
end

function M.report_dir()
  return root() .. "/res/错误报告"
end

function M.spool_dir()
  return M.report_dir() .. "/.ftp_upload_spool"
end

function M.audit_path()
  return M.spool_dir() .. "/_audit.log"
end

local function state_path(event_id)
  return M.spool_dir() .. "/" .. event_id .. "/state.json"
end

local function read_state(event_id)
  local f = io.open(state_path(event_id), "r")
  if not f then return nil end
  local body = f:read("*a") or ""
  f:close()
  if body:match('"event_id":"([^"]+)"') ~= event_id then return nil end
  local status = body:match('"status":"([^"]+)"')
  if status ~= "pending" and status ~= "sent" then return nil end
  return {
    event_id = event_id,
    status = status,
    attempts = tonumber(body:match('"attempts":(%d+)')) or 0,
    next_retry = tonumber(body:match('"next_retry":(%d+)')) or 0,
    created_at = tonumber(body:match('"created_at":(%d+)')) or 0,
    size = tonumber(body:match('"size":(%d+)')) or 0,
    large_file = body:find('"large_file":true', 1, true) ~= nil,
    large_file_verdict = body:match('"large_file_verdict":"([^"]+)"') or "N/A",
    resume_verdict = body:match('"resume_verdict":"([^"]+)"') or "N/A",
    last_error = body:match('"last_error":"(.-)"') or "",
    err_code = body:match('"err_code":"([^"]+)"') or "N/A",
    sha256 = body:match('"sha256":"([^"]+)"'),
    has_sidecar = body:find('"has_sidecar":true', 1, true) ~= nil,
    remote_name = body:match('"remote_name":"([^"]+)"'),
    resume_channel = body:match('"resume_channel":"([^"]*)"') or "",
  }
end

local function write_state(state)
  local last_error = tostring(state.last_error or "")
      :gsub("\\", "/"):gsub('"', "'"):gsub("[\r\n]", " "):sub(1, 200)
  local sha = state.sha256 and tostring(state.sha256):gsub("[^%x]", "") or ""
  if #sha ~= 64 then sha = "" end
  local remote_name = tostring(state.remote_name or ""):gsub('[^%w%._%-]', "")
  local body = string.format(
    '{"event_id":"%s","status":"%s","attempts":%d,"next_retry":%d,'
      .. '"created_at":%d,"size":%d,"large_file":%s,"resume_supported":%s,'
      .. '"large_file_verdict":"%s","resume_verdict":"%s",'
      .. '"err_code":"%s","sha256":"%s","has_sidecar":%s,"remote_name":"%s",'
      .. '"resume_channel":"%s",'
      .. '"last_error":"%s","updated_at":%d}\n',
    state.event_id, state.status or "pending", tonumber(state.attempts) or 0,
    tonumber(state.next_retry) or 0, tonumber(state.created_at) or os.time(),
    tonumber(state.size) or 0, state.large_file and "true" or "false",
    M.RESUME_SUPPORTED and "true" or "false",
    state.large_file and M.LARGE_FILE_VERDICT or "N/A",
    state.resume_verdict or (state.large_file and M.RESUME_VERDICT or "N/A"),
    tostring(state.err_code or "N/A"):gsub("[^%w_]", ""),
    sha, sha ~= "" and "true" or "false", remote_name,
    tostring(state.resume_channel or ""):gsub("[^%w_]", ""),
    last_error, os.time())
  return write_text(state_path(state.event_id), body)
end

local function retry_delay(attempts)
  local delay = M.BASE_RETRY_SEC
  local exponent = math.max((tonumber(attempts) or 1) - 1, 0)
  for _ = 1, math.min(exponent, 12) do
    delay = math.min(delay * 2, M.MAX_RETRY_SEC)
  end
  return delay
end

local function read_config_file()
  local result = {}
  local f = io.open(root() .. "/config/ftp_log.conf", "r")
  if not f then return result end
  for line in f:lines() do
    local key, value = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
    if key and not key:match("^#") then result[key:lower()] = value end
  end
  f:close()
  return result
end

function M.config()
  local global = type(_G.ZIYAN_FTP_LOG_CONFIG) == "table"
      and _G.ZIYAN_FTP_LOG_CONFIG or {}
  local file = read_config_file()
  local function env(name)
    return type(os.getenv) == "function" and os.getenv(name) or nil
  end
  local cfg = {
    host = trim(global.host or env("ZIYAN_FTP_HOST") or file.host),
    port = tonumber(global.port or env("ZIYAN_FTP_PORT") or file.port) or 21,
    user = trim(global.user or env("ZIYAN_FTP_USER") or file.user),
    password = tostring(global.password or env("ZIYAN_FTP_PASSWORD") or file.password or ""),
    remote_dir = trim(global.remote_dir or env("ZIYAN_FTP_REMOTE_DIR")
      or file.remote_dir or "ZiYanError"),
  }
  local missing = {}
  for _, key in ipairs({"host", "user", "password"}) do
    if cfg[key] == "" then missing[#missing + 1] = key end
  end
  if cfg.port < 1 or cfg.port > 65535 then missing[#missing + 1] = "port" end
  if not cfg.remote_dir:match("^[%w%._%-/]+$") or cfg.remote_dir:find("%.%.", 1, true) then
    missing[#missing + 1] = "remote_dir"
  end
  if #missing > 0 then return nil, "config_missing:" .. table.concat(missing, ",") end
  return cfg
end

--- 统计当前 pending 总量（不含 sent）。需求书 §三.6 要求「入队前统计所有 pending 文件大小」，
--- 因此本函数必须能在写入新条目之前独立调用，且执行淘汰。
--- @param incoming_bytes number|nil 即将入队的字节数（计入总量后再判定）
--- @param exclude_event_id string|nil 已落盘但属于本次入队的条目，统计时排除，
---        避免「扫描到它 + 再加 incoming」造成重复计数。
--- @return table { pending_bytes, evicted, cap }
function M.enforce_pending_cap(incoming_bytes, exclude_event_id)
  local entries, total = {}, 0
  for _, event_id in ipairs(list_dir(M.spool_dir())) do
    if valid_event_id(event_id) and event_id ~= exclude_event_id then
      local state = read_state(event_id)
      if state and state.status == "pending" then
        state.size = file_size(M.spool_dir() .. "/" .. event_id .. "/report.json")
            or state.size or 0
        total = total + state.size
        entries[#entries + 1] = state
      end
    end
  end
  -- 入队前统计：把待入队字节先计入，保证「超限时按创建时间删最旧」在写入前就完成
  total = total + math.max(tonumber(incoming_bytes) or 0, 0)
  table.sort(entries, function(a, b)
    if a.created_at == b.created_at then return a.event_id < b.event_id end
    return a.created_at < b.created_at
  end)
  local evicted = 0
  for _, state in ipairs(entries) do
    if total <= M.PENDING_CAP_BYTES then break end
    local dir = M.spool_dir() .. "/" .. state.event_id
    if remove_tree(dir) then
      total = total - state.size
      evicted = evicted + 1
      append_audit("EVICT", state.event_id, state.size,
        string.format("pending_cap_5MiB pending_bytes_after=%d cap=%d",
          math.max(total, 0), M.PENDING_CAP_BYTES))
    else
      append_audit("EVICT_FAILED", state.event_id, state.size,
        string.format("remove_failed pending_bytes=%d", total))
    end
  end
  return { pending_bytes = total, evicted = evicted, cap = M.PENDING_CAP_BYTES }
end

function M.enqueue(event_id, report_path)
  if not valid_event_id(event_id) then return false, "invalid_event_id" end
  local source = report_path or (M.report_dir() .. "/" .. event_id .. "/report.json")
  local size = file_size(source)
  if not size then return false, "report_unreadable" end
  local dir = M.spool_dir() .. "/" .. event_id
  if not mkdir_p(dir) then return false, "spool_mkdir_failed" end
  local target = dir .. "/report.json"
  local existing = file_size(target)
  if existing ~= size then
    local copied, copy_error = copy_file_chunked(source, target)
    if not copied then return false, copy_error or "report_copy_failed" end
  end

  -- 需求书 §三.7：如可得则生成 sha256 sidecar，供上传后远端校验。
  -- 无 sha 工具时如实置空（has_sidecar=false），不伪造校验通过。
  local sha = sha256_of(target)
  local sidecar = dir .. "/report.json.sha256"
  if sha then
    write_text(sidecar, sha .. "\n")
  else
    os.remove(sidecar)
  end

  local old = read_state(event_id)
  local state = {
    event_id = event_id,
    status = "pending",
    attempts = old and old.attempts or 0,
    next_retry = 0,
    created_at = old and old.created_at or os.time(),
    size = size,
    large_file = size >= M.LARGE_FILE_BYTES,
    large_file_verdict = size >= M.LARGE_FILE_BYTES and M.LARGE_FILE_VERDICT or "N/A",
    resume_verdict = size >= M.LARGE_FILE_BYTES and M.RESUME_VERDICT or "N/A",
    last_error = "",
    err_code = "N/A",
    sha256 = sha,
  }
  local saved, save_error = write_state(state)
  if not saved then return false, save_error or "state_write_failed" end
  -- 入队前统计（§三.6）：把本条字节计入后再判 5 MiB 上限，超限时先淘汰最旧 pending。
  -- 必须排除本条自身（已落盘），否则会被重复计入。
  local cap = M.enforce_pending_cap(size, event_id)
  if not file_size(target) then return false, "evicted_pending_cap" end
  return true, cap
end

local function fail_attempt(state, reason, now)
  state.status = "pending"
  state.attempts = (state.attempts or 0) + 1
  state.next_retry = now + retry_delay(state.attempts)
  state.last_error = tostring(reason or "ftp_failed")
  state.err_code = classify(state.last_error)
  return write_state(state)
end

--- 远端文件名：<设备唯一 ID>__<事件 ID>.json（需求书 §三.4）。
--- 保留 __event_id 后缀以便 macOS 端解析 event_id；device_uid 已做白名单净化。
local function remote_name_for(state)
  return device_uid() .. "__" .. state.event_id .. ".json"
end

local function upload_one(state, cfg, timeout, now)
  local dir = M.spool_dir() .. "/" .. state.event_id
  local local_path = dir .. "/report.json"
  local size = file_size(local_path)
  if not size then
    fail_attempt(state, "spool_missing", now)
    return false, "spool_missing"
  end
  local base = cfg.remote_dir:gsub("/+$", "")
  local name = state.remote_name
  if type(name) ~= "string" or name == "" then name = remote_name_for(state) end
  state.remote_name = name
  local remote_path = base .. "/" .. name
  local sidecar_path = dir .. "/report.json.sha256"
  local local_sha = state.sha256
  if type(local_sha) ~= "string" or #local_sha ~= 64 then local_sha = sha256_of(local_path) end
  if type(_G.FtpUpload) ~= "function" or type(_G.FtpIsUpdate) ~= "function" then
    fail_attempt(state, "ftp_primitive_missing", now)
    return false, "ftp_primitive_missing"
  end
  local called, uploaded = pcall(
    _G.FtpUpload, cfg.host, cfg.user, cfg.password, local_path, remote_path,
    cfg.port, timeout)
  if not called or type(uploaded) ~= "table" or uploaded.ok ~= true then
    local reason = called and type(uploaded) == "table" and uploaded.error or uploaded
    fail_attempt(state, reason or "ftp_upload_failed", now)
    return false, state.last_error
  end
  -- 记录本次实际走的传输通道与续传能力（按次观测，不冒充全局常量）。
  -- python_ftplib 通道已实现 REST 续传并经 .61 真机验证；
  -- curl 通道（-T）为整传覆盖，不宣称续传。
  if type(uploaded) == "table" then
    state.resume_channel = tostring(uploaded.via or "unknown"):gsub("[^%w_]", "")
    state.resume_verdict = (state.resume_channel == "python_ftplib") and "SUPPORTED_REST"
      or "FULL_OVERWRITE"
  end

  local size_called, checked = pcall(
    _G.FtpIsUpdate, cfg.host, cfg.user, cfg.password, remote_path, local_path,
    cfg.port, timeout)
  if not size_called or type(checked) ~= "table" or checked.ok ~= true then
    local reason = size_called and type(checked) == "table" and checked.error or checked
    fail_attempt(state, "remote_size_unavailable:" .. tostring(reason or "unknown"), now)
    return false, state.last_error
  end
  if checked.updated ~= false or tonumber(checked.remote_size) ~= size
      or tonumber(checked.local_size) ~= size then
    fail_attempt(state, "remote_size_mismatch", now)
    return false, state.last_error
  end

  -- 需求书 §三.7：如有 sha256 sidecar，远端校验值必须一致才判成功。
  -- sidecar 上传/比对失败一律按失败处理并保留本地文件。
  if local_sha and #local_sha == 64 and file_size(sidecar_path) then
    if type(_G.FtpRead) ~= "function" then
      fail_attempt(state, "hash_sidecar_unverifiable:ftp_read_missing", now)
      return false, state.last_error
    end
    local up_called, up_ok = pcall(
      _G.FtpUpload, cfg.host, cfg.user, cfg.password, sidecar_path,
      remote_path .. ".sha256", cfg.port, timeout)
    if not up_called or type(up_ok) ~= "table" or up_ok.ok ~= true then
      fail_attempt(state, "hash_sidecar_upload_failed", now)
      return false, state.last_error
    end
    local rd_called, remote_side = pcall(
      _G.FtpRead, cfg.host, cfg.user, cfg.password, remote_path .. ".sha256",
      cfg.port, timeout)
    local remote_sha = rd_called and type(remote_side) == "table" and remote_side.ok
        and tostring(remote_side.data or ""):match("(%x+)") or nil
    if not remote_sha or #remote_sha ~= 64 then
      fail_attempt(state, "hash_sidecar_unreadable", now)
      return false, state.last_error
    end
    if remote_sha:lower() ~= local_sha:lower() then
      fail_attempt(state, "hash_mismatch:" .. remote_sha:lower() .. "!=" .. local_sha:lower(), now)
      return false, state.last_error
    end
  end
  state.status = "sent"
  state.attempts = (state.attempts or 0) + 1
  state.next_retry = 0
  state.last_error = ""
  state.err_code = "N/A"
  if not write_state(state) then return false, "state_commit_failed" end
  if not remove_tree(dir) then
    append_audit("SENT_LOCAL_DELETE_FAILED", state.event_id, size, remote_path)
    return true, "local_delete_failed"
  end
  append_audit("SENT_DELETE", state.event_id, size, remote_path)
  return true
end

function M.flush(opts)
  opts = type(opts) == "table" and opts or {}
  local now = tonumber(opts.now) or os.time()
  local batch = tonumber(opts.batch) or M.BATCH
  local timeout = tonumber(opts.timeout) or 30
  local stats = { tried = 0, sent = 0, pending = 0, blocked = 0 }
  local cfg, config_error = M.config()
  local pending = {}
  for _, event_id in ipairs(list_dir(M.spool_dir())) do
    if valid_event_id(event_id) then
      local state = read_state(event_id)
      if state and state.status == "pending" then pending[#pending + 1] = state end
    end
  end
  table.sort(pending, function(a, b)
    if a.created_at == b.created_at then return a.event_id < b.event_id end
    return a.created_at < b.created_at
  end)
  if not cfg then
    stats.pending = #pending
    stats.blocked = #pending
    stats.last_error = config_error
    return stats
  end
  for _, state in ipairs(pending) do
    if stats.tried >= batch then
      stats.pending = stats.pending + 1
    elseif opts.force or state.next_retry <= now then
      stats.tried = stats.tried + 1
      local ok, reason = upload_one(state, cfg, timeout, now)
      if ok then
        stats.sent = stats.sent + 1
        if reason == "local_delete_failed" then
          stats.storage_errors = (stats.storage_errors or 0) + 1
        end
      else
        stats.pending = stats.pending + 1
        stats.last_error = reason
      end
    else
      stats.pending = stats.pending + 1
    end
  end
  return stats
end

function M.pending_count()
  local count = 0
  for _, event_id in ipairs(list_dir(M.spool_dir())) do
    local state = valid_event_id(event_id) and read_state(event_id)
    if state and state.status == "pending" then count = count + 1 end
  end
  return count
end

--- 2026-09-17 补：清理已发送的 spool 条目（对齐 OfflineQueue.cleanup_sent）。
--
-- 为什么需要：本模块的 state.json 一直记 status="sent"（见写状态处），
-- 但此前【没有任何清理函数】—— OfflineQueue 侧有 cleanup_sent，FTP 侧没有。
-- 于是 sent 条目会永久累积，既占磁盘又让每次 pending_count()/flush() 多遍历。
-- 实测 .101：ftp_spool 104 条占 1.3MB。当前 103 条是 pending（服务器不可达，
-- 属网络问题，不能删），但一旦网络恢复、sent 开始产生，没有本函数就会无限增长。
--
-- 只删 status=="sent" 且已过保留期的条目；pending 一律保留（绝不丢待传证据）。
-- sent_at 缺失时保守跳过，不靠 mtime 猜（mtime 会被读取/触碰改变）。
function M.cleanup_sent(older_than_sec)
  local cutoff = os.time() - (tonumber(older_than_sec) or 3 * 86400)
  local removed = 0
  for _, event_id in ipairs(list_dir(M.spool_dir())) do
    if valid_event_id(event_id) then
      local state = read_state(event_id)
      if state and state.status == "sent" then
        local sentAt = tonumber(state.sent_at) or 0
        if sentAt > 0 and sentAt < cutoff then
          local dir = M.spool_dir() .. "/" .. event_id
          local ok, removed_ok = pcall(remove_tree, dir)
          if ok and removed_ok then removed = removed + 1 end
        end
      end
    end
  end
  return removed
end

function M.install()
  _G.FtpErrorUploader = M
  _G.__ZIYAN_FTP_ERROR_UPLOADER = M.version
  pcall(mkdir_p, M.spool_dir())
  return M
end

return M
