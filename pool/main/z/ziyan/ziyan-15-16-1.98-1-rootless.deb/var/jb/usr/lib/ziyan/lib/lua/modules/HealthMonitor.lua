--[[ HealthMonitor — 24/7 全自动化健康监控系统
  在 while true 循环的 mSleep 中透明注入，自动检测并修复运行时渐进式退化。
  用户脚本零感知，零修改。

  检查频率分层：
    每 10 轮 (~5s):   快速检查 — 内存趋势、视觉耗时降载、toast 抑制
    每 100 轮 (~50s):  中等检查 — 磁盘空间、文件描述符、计时器漂移、网络
    每 1000 轮 (~8min): 深度检查 — 视觉未命中、电量、GC
    每 10000 轮 (~83min): 预防性释放与降级，不停止 VM
]]

local M = { name = "HealthMonitor", version = "1.1.0" }

local ZS = (function()
  local ok, mod = pcall(require, "zy_shell")
  if ok and type(mod) == "table" and type(mod.run_capture) == "function" then return mod end
  local base = _G.ZIYAN_LUA or "/usr/lib/ziyan/lib/lua"
  for _, path in ipairs({
    base .. "/modules/zy_shell.lua",
    "/var/jb/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
    "/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
  }) do
    local f = io.open(path, "r")
    if f then
      f:close()
      local loaded, candidate = pcall(dofile, path)
      if loaded and type(candidate) == "table"
          and type(candidate.run_capture) == "function" then
        return candidate
      end
    end
  end
  return nil
end)()

local function shell_capture(cmd)
  if not ZS then return "" end
  return ZS.run_capture(cmd) or ""
end

---------------------------------------------------------------------------
-- 配置
---------------------------------------------------------------------------
M.PULSE_FAST   = 10      -- 快速检查间隔（轮）
M.PULSE_MEDIUM = 100     -- 中等检查间隔（轮）
M.PULSE_DEEP   = 1000    -- 深度检查间隔（轮）
M.PULSE_REBOOT = 10000   -- 预防性释放/降级间隔（轮）；保留旧字段名

-- 内存趋势
M.MEM_SLOPE_WARN  = 1.0   -- MB/10min 告警
M.MEM_SLOPE_GC    = 3.0   -- MB/10min 强制 GC
M.MEM_SLOPE_EXIT  = 5.0   -- MB/10min 释放/降级阈值，不退出 VM
M.MEM_RSS_CRITICAL = 140  -- 绝对 RSS 熔断线（MB）

-- 磁盘
M.DISK_CRITICAL = 95      -- critical 状态并释放/降级，不停止 VM
M.DISK_SEVERE   = 90      -- 只告警，不删除业务截图
M.DISK_WARN     = 80      -- 只告警
M.DISK_NOTE     = 70      -- 只返回 note

-- 文件描述符
M.FD_WARN  = 200
M.FD_EXIT  = 500

-- Toast 抑制（每轮 toast 会导致 UIKit 内存累积）
M.TOAST_MIN_INTERVAL_MS = 3000  -- 同一消息最小间隔
M.TOAST_SUPPRESS_SEARCHING = true  -- 抑制 "searching" 类 toast
M.NET_CHECK_INTERVAL_SEC = 300    -- ping 失败最多每 5 分钟一次，避免业务线程被 -t2 阻塞

---------------------------------------------------------------------------
-- 内部状态
---------------------------------------------------------------------------
M.loop_count = 0
M.start_time = 0
M.health_status = "ok"         -- ok / warn / degraded / critical
M.health_history = {}          -- 最近 100 条事件
M._last_toast_ts = {}          -- {msg_key → timestamp} 防重复 toast
M._last_toast_msg = ""         -- 上次 toast 内容
M._last_toast_time = 0         -- 上次 toast 时间
M._cycle_ms = 500              -- 当前动态间隔（供 SafeExecutor 读写）
M._degraded = false            -- 是否已降级
M._last_find_ms = 0            -- 最近一次找色耗时（ms）
M._no_find_count = 0           -- 连续未找到计数
M._max_no_find_cooldown = 10   -- 连续 N 次未找到 → 进入冷却期

-- 内存趋势采样
M._mem_samples = {}            -- {t=os.time(), rss=MB}
M._mem_window_sec = 600        -- 10 分钟窗口
M._mem_slope_exit_streak = 0

-- 网络
M._net_fail_count = 0
M._net_offline_mode = false
M._net_last_check = 0
M._toast_key_limit = 64

-- 文件描述符
M._fd_last_check = 0
M._fd_last_count = -1

-- BEGIN SYSTEM_THERMAL_OBSERVATION
-- SDK 枚举观测；0 Nominal 不证明凉爽或平台支持。
local system_thermal = {
  raw = -1, valid = false, state = "UNKNOWN", sample_seq = 0, streak = 0,
  source = "UNKNOWN",
  stable = -1, pending = -1, direction = 0,
}
local system_thermal_names = { [0] = "NORMAL", "WARM", "HOT", "CRITICAL" }
local thermal_hold, thermal_clock_active = false, false
local thermal_last_sample, thermal_last_clock
local thermal_freshness, thermal_activation = "UNKNOWN", "BLOCKED_CLOCK"
local thermal_release_status, thermal_release_return = "NOT_ATTEMPTED", nil
-- 保留加载时的栈查询入口，业务清理 debug 全局也不影响触控隔离。
local thermal_getinfo = debug and type(debug.getinfo) == "function" and debug.getinfo

local function invalidate_thermal()
  local t = system_thermal
  t.raw, t.valid, t.state = -1, false, "UNKNOWN"
  t.pending, t.direction, t.streak = -1, 0, 0
  -- 未持有时旧 stable 不能替代两次新鲜 CRITICAL；已持有则保留恢复滞回。
  t.stable = thermal_hold and 3 or -1
  thermal_freshness = "UNKNOWN"
end

local function thermal_now()
  local mono = _G.ziyan_embed_monotonic_ms
  if type(mono) ~= "function" then return nil end
  local ok, now = pcall(mono)
  if ok and type(now) == "number" and now >= 0 and now < math.huge then
    return now
  end
end

local function sample_system_thermal()
  local t = system_thermal
  t.sample_seq = t.sample_seq + 1  -- 每次 fast 检查尝试计一次，包括缺失/失败。
  local provider = _G.ziyan_embed_thermal_state
  -- 表示本次尝试的 provider 标识，不证明平台支持/成功或传感器温度。
  t.source = type(provider) == "function" and "ziyan_embed_thermal_state" or "UNKNOWN"
  local ok, raw = false, nil
  if type(provider) == "function" then ok, raw = pcall(provider) end
  t.valid = ok and type(raw) == "number" and raw == raw
      and raw >= 0 and raw <= 3 and raw == math.floor(raw)
  t.raw = t.valid and raw or -1
  if not t.valid then
    t.state = "UNKNOWN"
    t.pending, t.direction, t.streak = -1, 0, 0
    -- UNKNOWN 中断恢复计数，不能借未知样本解除高温保护。
    return
  end

  if t.stable < 0 or raw > t.stable then
    -- 同/更高两次进入首个候选级别；更低样本重新开始，不能认证未连续出现的高值。
    if t.direction ~= 1 or raw < t.pending then
      t.pending, t.direction, t.streak = raw, 1, 1
    else
      t.streak = t.streak + 1
    end
    if t.streak == 2 then
      t.stable = t.pending
      t.pending, t.direction, t.streak = -1, 0, 0
    end
  elseif raw < t.stable and (t.stable ~= 3 or raw <= 1) then
    -- 连续三次低热恢复到其中最高等级；CRITICAL 接受 Nominal/Fair。
    if t.direction ~= -1 then
      t.pending, t.direction, t.streak = raw, -1, 1
    else
      t.pending = math.max(t.pending, raw)
      t.streak = t.streak + 1
    end
    if t.streak == 3 then
      t.stable = t.pending
      t.pending, t.direction, t.streak = -1, 0, 0
    end
  else
    t.pending, t.direction, t.streak = -1, 0, 0
  end
  t.state = system_thermal_names[t.stable] or "UNKNOWN"
end

-- 单 VM 私有协作暂停；不写用户标志，不冻结进程，不回收帧内存。
function M.thermal_tick()
  -- 共用暂停/mSleep 也被 touch 的回执轮询和重试调用；整条触控栈不参与热动作。
  if not thermal_getinfo then
    thermal_activation = "BLOCKED_STACK"
    return false
  end
  local level = 2
  while true do
    local caller = thermal_getinfo(level, "S")
    if not caller then break end
    if caller.source:match("/ziyan_engine/touch%.lua$") then return false end
    level = level + 1
  end
  local now = thermal_now()
  if not now then
    invalidate_thermal()
    thermal_last_sample, thermal_last_clock = nil, nil
    thermal_activation = "BLOCKED_CLOCK"
    return thermal_hold
  end
  if not thermal_clock_active then
    invalidate_thermal()
    thermal_clock_active = true
  end
  if (thermal_last_clock and now < thermal_last_clock)
      or (thermal_last_sample and now - thermal_last_sample > 3000) then
    invalidate_thermal()
    thermal_last_sample, thermal_last_clock = now, now
    thermal_activation = "BLOCKED_FRESHNESS"
    return thermal_hold
  end
  thermal_last_clock = now
  local sleep = _G.ziyan_embed_msleep
  if not _G.ZIYAN_EMBED or type(sleep) ~= "function" then
    invalidate_thermal()
    thermal_last_sample = nil
    thermal_activation = "BLOCKED_SLEEP"
    return thermal_hold
  end
  if thermal_last_sample and now - thermal_last_sample < 1000 then
    return thermal_hold
  end
  thermal_last_sample = now
  -- 只探测原生入口；异常保留 terminal token，不吞掉 native stop。
  local sleep_ok, sleep_result = pcall(sleep, 0)
  if not sleep_ok or sleep_result == false then
    invalidate_thermal()
    thermal_activation = "BLOCKED_SLEEP"
    if not sleep_ok then error(sleep_result, 0) end
    return thermal_hold
  end
  sample_system_thermal()
  local after = thermal_now()
  if not after or after < now or after - now > 3000 then
    invalidate_thermal()
    thermal_last_sample, thermal_last_clock = after, after
    thermal_activation = "BLOCKED_FRESHNESS"
    return thermal_hold
  end
  thermal_last_sample, thermal_last_clock = after, after
  thermal_freshness = system_thermal.valid and "FRESH" or "UNKNOWN"
  thermal_activation = system_thermal.valid and "READY" or "BLOCKED_PROVIDER"
  if system_thermal.valid and system_thermal.stable == 3 and not thermal_hold then
    thermal_hold = true
    local release = _G.ziyan_embed_keep_screen
    thermal_release_return = nil
    if type(release) ~= "function" then
      thermal_release_status = "UNSUPPORTED"
    else
      local ok, result = pcall(release, false)
      thermal_release_return = result
      thermal_release_status = not ok and "ERROR"
          or (result == true and "UNLOCKED" or (result == false and "FAILED" or "UNKNOWN_RETURN"))
    end
  elseif thermal_hold and system_thermal.valid
      and system_thermal.stable >= 0 and system_thermal.stable <= 1 then
    thermal_hold = false
  end
  return thermal_hold
end

local wait_last_time, wait_last_state
function M.wait_heartbeat(reason)
  local heartbeat = _G.ziyan_embed_wait_heartbeat
  if type(heartbeat) ~= "function" then return end
  local now = thermal_now() or os.time() * 1000
  local state = table.concat({reason, system_thermal.raw,
      tostring(thermal_hold), thermal_activation}, ":")
  if state == wait_last_state and wait_last_time
      and now >= wait_last_time and now - wait_last_time < 3000 then return end
  -- 只续 VM 存活，不调用 pulse 或增加业务进展；原生停止信号继续向上传递。
  heartbeat(reason, system_thermal.raw, reason == "user_pause" or thermal_hold, thermal_activation)
  wait_last_time, wait_last_state = now, state
end

-- 仅供自动诊断附图：复用同一 observer 的原生限频、资格与恢复滞回。
-- 首个 HOT raw 即拒绝；未知/过龄/未就绪关闭准入，不影响显式截图与业务像素。
function M.thermal_diagnostic_allowed()
  M.thermal_tick()  -- native stop 异常继续向上传递，不运行 pulse/健康探测。
  return thermal_activation == "READY" and thermal_freshness == "FRESH"
      and system_thermal.valid and system_thermal.raw >= 0 and system_thermal.raw <= 1
      and system_thermal.stable >= 0 and system_thermal.stable <= 1
      and not thermal_hold
end
-- END SYSTEM_THERMAL_OBSERVATION

---------------------------------------------------------------------------
-- 工具函数
---------------------------------------------------------------------------

local function var_dir()
  if type(_G.ZIYAN_VAR) == "string" and #_G.ZIYAN_VAR > 0 then
    return _G.ZIYAN_VAR
  end
  local f = io.open("/var/jb/usr/lib/ziyan/var", "r")
  if f then
    f:close()
    return "/var/jb/usr/lib/ziyan/var"
  end
  return "/usr/lib/ziyan/var"
end

local function media_dir()
  if type(_G.ZIYAN_SCRIPTS) == "string" and #_G.ZIYAN_SCRIPTS > 0 then
    return _G.ZIYAN_SCRIPTS
  end
  return "/private/var/mobile/Media/ZiYan"
end

-- 当前进程 RSS（整数 MB）；缺失/无效为 -1，绝不把未知当作 0MB。
local function get_rss_mb()
  -- 支持 /proc 的宿主直接取 self；iOS 不假定有 /proc。
  local f = io.open("/proc/self/status", "r")
  if f then
    local body = f:read("*a") or ""
    f:close()
    local vm = body:match("VmRSS:%s*(%d+)")
    if vm and tonumber(vm) >= 1024 and tonumber(vm) < math.huge then
      return math.floor(tonumber(vm) / 1024)  -- kB → MB
    end
  end
  -- Embed 已由 native getpid() 注入宿主 PID；$$/PPID 属于嵌套子 shell。
  local pid = tonumber(_G.ZIYAN_HOST_PID)
  if not pid or pid <= 0 or pid >= math.huge or pid ~= math.floor(pid) then return -1 end
  local line = shell_capture(string.format("ps -o rss= -p %.0f 2>/dev/null", pid))
  local kb = tonumber(line:match("^%s*(%d+)%s*$"))
  if kb and kb >= 1024 and kb < math.huge then
    return math.floor(kb / 1024)
  end
  return -1
end

-- SafeExecutor 复用同一采样入口，避免 summary() 的磁盘/电量等附带采集。
M.get_rss_mb = get_rss_mb

-- FD 必须属于 Lua 宿主；缺工具/失败/无法归属时保留未知，不把子 shell 当宿主。
local function get_fd_count()
  local native = _G.ziyan_embed_fd_count
  if type(native) == "function" then
    local ok, count = pcall(native)
    if ok and type(count) == "number" and count == count and count >= 0
        and count <= 2147483647 and count == math.floor(count) then
      return count
    end
    return -1
  end
  local raw = _G.ZIYAN_HOST_PID
  if type(raw) ~= "number" and type(raw) ~= "string" then return -1 end
  if type(raw) == "string" and not raw:match("^%d+$") then return -1 end
  local pid = tonumber(raw)
  if not pid or pid ~= pid or pid <= 0 or pid > 2147483647
      or pid ~= math.floor(pid) then return -1 end
  if not ZS or type(ZS.run_capture_status) ~= "function" then return -1 end
  local target = string.format("%.0f", pid)
  local ok, body, rc = pcall(ZS.run_capture_status,
    "lsof -a -p " .. target .. " -d 0-2147483647 -F f 2>/dev/null")
  if not ok or rc ~= 0 or type(body) ~= "string" or #body > 65536
      or not body:match("^p" .. target .. "\n") or body:find("\n\n", 1, true) then
    return -1
  end
  local count, seen = 0, {}
  for line in body:sub(#target + 3):gmatch("[^\n]+") do
    local fd = tonumber(line:match("^f(%d+)$"))
    if not fd or fd > 2147483647 or seen[fd] then return -1 end
    seen[fd], count = true, count + 1
  end
  return count > 0 and count or -1
end

-- 获取磁盘使用率
local function get_disk_usage_pct()
  local path = media_dir()
  if path:sub(1, 1) ~= "/" or path:find("\0", 1, true) then return 0 end
  local quoted = "'" .. path:gsub("'", "'\\''") .. "'"
  local line = shell_capture("df -k " .. quoted .. " 2>/dev/null | tail -1")
  local pct = line:match("(%d+)%%")
  return tonumber(pct) or 0
end

-- 获取电量
local function get_battery_pct()
  local f = io.open("/private/var/mobile/Library/BatteryLife/CurrentCapacity.txt", "r")
  if f then
    local val = tonumber(f:read("*l"))
    f:close()
    if val then return val end
  end
  -- 备用：ioreg
  local val = tonumber(shell_capture(
    "ioreg -r -c AppleSmartBattery | grep '\"CurrentCapacity\"' | awk '{print $NF}' 2>/dev/null"))
  if val then return val end
  return 100
end

-- 检查是否在充电
local function is_charging()
  local val = tonumber(shell_capture(
    "ioreg -r -c AppleSmartBattery | grep '\"ExternalConnected\"' | grep -c Yes 2>/dev/null"))
  return val == nil and true or val > 0
end

-- ping 网关检测网络
local function ping_gateway()
  local gw = shell_capture("route -n get default 2>/dev/null | grep gateway | awk '{print $2}'")
  gw = gw:gsub("%s+$", "")
  -- 字符白名单与引号隔离 shell 参数；不等于完整地址解析或禁止 DNS。
  if #gw > 128 or not (gw:match("^[%x:%.]+$")
      or gw:match("^[%x:%.]+%%[%w_.%-]+$")) then return false end
  local ok = os.execute("ping -c1 -t2 '" .. gw .. "' >/dev/null 2>&1")
  return ok == 0 or ok == true
end

-- 写入健康日志
local function health_log_path()
  return var_dir() .. "/.ziyan_health_log.jsonl"
end

local function write_health_log(event, detail)
  local rss = get_rss_mb()
  local line = string.format(
    '{"ts":%d,"loop":%d,"rss":%s,"rss_valid":%s,"event":%q,"detail":%q,"status":%q}\n',
    os.time(), M.loop_count, rss > 0 and tostring(rss) or "null",
    tostring(rss > 0), tostring(event),
    tostring(detail or ""):sub(1, 100), M.health_status)
  pcall(function()
    local f = io.open(health_log_path(), "a")
    if f then f:write(line); f:close() end
  end)
end

---------------------------------------------------------------------------
-- 检查器 1: MemoryTrend — 内存趋势监控
---------------------------------------------------------------------------
local function check_memory_trend()
  local rss = get_rss_mb()
  if rss <= 0 then
    M._mem_slope_exit_streak = 0
    return "unknown"
  end

  -- 记录采样
  table.insert(M._mem_samples, { t = os.time(), rss = rss })
  local cutoff = os.time() - M._mem_window_sec
  while #M._mem_samples > 0 and M._mem_samples[1].t < cutoff do
    table.remove(M._mem_samples, 1)
  end

  -- 绝对 RSS 熔断
  if rss > M.MEM_RSS_CRITICAL then
    M.health_status = "critical"
    write_health_log("rss_critical", string.format("rss=%dMB", rss))
    return "exit"
  end

  -- 计算斜率
  if #M._mem_samples >= 2 then
    local first = M._mem_samples[1]
    local last = M._mem_samples[#M._mem_samples]
    local dt_min = (last.t - first.t) / 60
    if dt_min * 60 >= M._mem_window_sec then
      local slope = (last.rss - first.rss) / dt_min * 10  -- MB/10min
      if slope > M.MEM_SLOPE_EXIT then
        M._mem_slope_exit_streak = M._mem_slope_exit_streak + 1
        if M._mem_slope_exit_streak >= 3 then
          M.health_status = "critical"
          write_health_log("mem_leak_exit", string.format("slope=%.1f rss=%d", slope, rss))
          return "exit"
        end
        return "ok"
      elseif slope > M.MEM_SLOPE_GC then
        M._mem_slope_exit_streak = 0
        M.health_status = "degraded"
        collectgarbage("collect")
        write_health_log("mem_leak_gc", string.format("slope=%.1f rss=%d", slope, rss))
        return "gc"
      elseif slope > M.MEM_SLOPE_WARN then
        M._mem_slope_exit_streak = 0
        M.health_status = "warn"
        write_health_log("mem_leak_warn", string.format("slope=%.1f rss=%d", slope, rss))
        return "warn"
      else
        M._mem_slope_exit_streak = 0
      end
    else
      M._mem_slope_exit_streak = 0
    end
  else
    M._mem_slope_exit_streak = 0
  end

  -- 恢复检测
  if M.health_status == "warn" or M.health_status == "degraded" then
    if rss < 50 then
      M.health_status = "ok"
      write_health_log("mem_recovered", string.format("rss=%d", rss))
    end
  end

  return "ok"
end

---------------------------------------------------------------------------
-- 检查器 2: DiskGuard — 磁盘空间保护
---------------------------------------------------------------------------
local function check_disk()
  local pct = get_disk_usage_pct()
  if pct <= 0 then return "ok" end

  if pct >= M.DISK_CRITICAL then
    M.health_status = "critical"
    write_health_log("disk_critical", string.format("pct=%d", pct))
    return "critical"
  elseif pct >= M.DISK_SEVERE then
    -- shortcut: 未建立文件所有权/活跃请求身份前只告警，不递归删除业务资源或 IPC。
    write_health_log("disk_severe", string.format("pct=%d", pct))
    return "severe"
  elseif pct >= M.DISK_WARN then
    write_health_log("disk_warn", string.format("pct=%d", pct))
    return "warn"
  elseif pct >= M.DISK_NOTE then
    return "note"
  end
  return "ok"
end

---------------------------------------------------------------------------
-- 检查器 3: FDLeakDetector — 文件描述符泄漏
---------------------------------------------------------------------------
local function check_fd_leak()
  local count = get_fd_count()
  M._fd_last_count = count
  if count < 0 then return "unknown" end

  if count >= M.FD_EXIT then
    M.health_status = "critical"
    write_health_log("fd_leak_exit", string.format("count=%d", count))
    return "exit"
  elseif count >= M.FD_WARN then
    M.health_status = "warn"
    write_health_log("fd_leak_warn", string.format("count=%d", count))
    return "warn"
  end
  return "ok"
end

---------------------------------------------------------------------------
-- 检查器 4: TimerDrift — 计时器漂移校正
---------------------------------------------------------------------------
---------------------------------------------------------------------------
-- 检查器 5: NetworkHealth — 网络健康
---------------------------------------------------------------------------
local function check_network()
  local now = os.time()
  if M._net_last_check > 0
      and now - M._net_last_check < M.NET_CHECK_INTERVAL_SEC then
    return "cached"
  end
  M._net_last_check = now

  if M._net_offline_mode then
    if ping_gateway() then
      M._net_fail_count = 0
      M._net_offline_mode = false
      write_health_log("net_recovered")
      return "recovered"
    end
    return "offline"
  end

  if ping_gateway() then
    M._net_fail_count = 0
    return "ok"
  end

  M._net_fail_count = M._net_fail_count + 1
  if M._net_fail_count >= 10 then
    M._net_offline_mode = true
    write_health_log("net_offline", "fail_count=10")
    return "offline"
  elseif M._net_fail_count >= 5 then
    write_health_log("net_hard_recover", "fail_count=5")
    return "recover_hard"
  elseif M._net_fail_count >= 3 then
    write_health_log("net_soft_recover", "fail_count=3")
    return "recover_soft"
  end
  return "retry"
end

---------------------------------------------------------------------------
-- 检查器 6: PowerGuard — 电量保护
---------------------------------------------------------------------------
local function check_power()
  local pct = get_battery_pct()
  local charging = is_charging()

  if pct < 5 and not charging then
    M.health_status = "critical"
    write_health_log("battery_critical", string.format("pct=%d charging=%s", pct, tostring(charging)))
    return "critical"
  elseif pct < 10 and not charging then
    M.health_status = "degraded"
    write_health_log("battery_low", string.format("pct=%d", pct))
    return "pause"
  elseif pct < 20 and not charging then
    M.health_status = "warn"
    write_health_log("battery_warn", string.format("pct=%d", pct))
    return "throttle"
  end

  -- 充电恢复
  if charging and (M.health_status == "degraded" or M.health_status == "warn") then
    M.health_status = "ok"
    write_health_log("battery_charging", string.format("pct=%d", pct))
  end

  return "ok"
end

---------------------------------------------------------------------------
-- 检查器 7: ThermalGuard — 视觉耗时降载启发式，不是系统 thermal state
---------------------------------------------------------------------------
local function check_thermal()
  if M._last_find_ms <= 0 then return "ok" end

  if M._last_find_ms > 200 then
    M.health_status = "degraded"
    M._cycle_ms = math.min(M._cycle_ms * 2, 5000)
    write_health_log("thermal_slow", string.format("find_ms=%d", M._last_find_ms))
    return "slow"
  elseif M._last_find_ms > 100 then
    M.health_status = "warn"
    M._cycle_ms = math.min(M._cycle_ms * 1.5, 2000)
    write_health_log("thermal_warn", string.format("find_ms=%d", M._last_find_ms))
    return "warn"
  elseif M._last_find_ms < 50 and M.health_status == "degraded" then
    M.health_status = "ok"
    M._cycle_ms = math.max(M._cycle_ms / 2, 500)
    if M._cycle_ms <= 500 then M._degraded = false end
    write_health_log("thermal_recovered", string.format("find_ms=%d", M._last_find_ms))
  end

  return "ok"
end

-- 检查器 8: RuntimeHealth — 通用运行时健康检测
---------------------------------------------------------------------------
local function check_runtime_health()
  -- 运行时只记录视觉连续未命中，不读取前台 Bundle，也不拉起或切换 App。
  if M._no_find_count > 100 then
    write_health_log("visual_no_find_100", string.format("no_find=%d", M._no_find_count))
    return "warn"
  end

  return "ok"
end

---------------------------------------------------------------------------
-- Toast 抑制（防止每轮 toast 导致 UIKit 内存累积）
---------------------------------------------------------------------------
local _original_toast = nil

local function smart_toast(msg, duration)
  -- 抑制 "searching" 类无意义 toast
  local msg_str = tostring(msg or "")
  if M.TOAST_SUPPRESS_SEARCHING and msg_str:find("earch", 1, true) then
    -- 只在首次或每 30 轮输出一次
    if M.loop_count % 30 ~= 0 then
      return
    end
  end

  -- 同消息防抖
  local now = os.time() * 1000
  local key = msg_str:sub(1, 40)
  local last = M._last_toast_ts[key] or 0
  if (now - last) < M.TOAST_MIN_INTERVAL_MS then
    return
  end
  if not M._last_toast_ts[key] then
    local key_count = 0
    for _ in pairs(M._last_toast_ts) do
      key_count = key_count + 1
    end
    if key_count >= M._toast_key_limit then
      M._last_toast_ts = {}
    end
  end
  M._last_toast_ts[key] = now

  -- 调用原始 toast
  if _original_toast then
    _original_toast(msg_str, duration)
  end
end

---------------------------------------------------------------------------
-- 保存状态快照（供守护进程恢复）
---------------------------------------------------------------------------
local function save_snapshot(reason)
  local snapshot = {
    ts = os.time(),
    reason = tostring(reason or "unknown"),
    loop_count = M.loop_count,
    rss = get_rss_mb(),
    health_status = M.health_status,
    script = _G.__ZIYAN_CURRENT_SCRIPT or "unknown",
    bid = type(_G.gameDefaultBid) == "function" and tostring(_G.gameDefaultBid()) or "",
  }
  local path = var_dir() .. "/.ziyan_health_snapshot.json"
  pcall(function()
    local f = io.open(path, "w")
    if f then
      -- 手动构建 JSON（避免依赖 json 模块）
      f:write(string.format(
        '{"ts":%d,"reason":%q,"loop":%d,"rss":%s,"rss_valid":%s,"status":%q,"script":%q,"bid":%q}\n',
        snapshot.ts, snapshot.reason, snapshot.loop_count,
        snapshot.rss > 0 and tostring(snapshot.rss) or "null",
        tostring(snapshot.rss > 0), snapshot.health_status, snapshot.script, snapshot.bid))
      f:close()
    end
  end)
  write_health_log("snapshot_saved", reason)
end

---------------------------------------------------------------------------
-- 保留旧函数名：保存快照并释放/降级，不退出 VM
---------------------------------------------------------------------------
local function proactive_exit(reason)
  -- 8-161-99：禁止主动 os.exit——业务未调 lua_exit() 不得停（对照触动长跑）
  save_snapshot(reason)
  write_health_log("proactive_exit_suppressed", tostring(reason or ""))
  if type(_G.keepScreen) == "function" then pcall(_G.keepScreen, false) end
  collectgarbage("collect")
  M._degraded = true
end

---------------------------------------------------------------------------
-- 核心: pulse() — 每轮 mSleep 中调用
---------------------------------------------------------------------------
function M.pulse()
  M.loop_count = M.loop_count + 1

  -- 8-142：进程心跳（终稿 §4.1），供 ZiyanProcessWatchdog 观测 lua 存活
  pcall(function()
    local now = os.time()
    if (M._last_hb_ts or 0) + 3 <= now then
      M._last_hb_ts = now
      local f = io.open(var_dir() .. "/.ziyan_heartbeat_lua5.3", "w")
      if f then
        f:write(string.format("ts=%d loop=%d pid=lua\n", now, M.loop_count))
        f:close()
      end
    end
  end)

  -- 快速检查（每 10 轮）
  if M.loop_count % M.PULSE_FAST == 0 then
    if type(_G.ziyan_embed_monotonic_ms) == "function" or thermal_clock_active then
      M.thermal_tick()
    else
      -- 兼容无 native 时钟的既有 observer；此路径始终只观测、不获取 hold。
      sample_system_thermal()
    end
    -- 内存趋势
    local mem = check_memory_trend()
    if mem == "exit" then
      proactive_exit("memory_critical")
      return
    end

    -- 热降频
    local thermal = check_thermal()
    if thermal == "slow" then
      M._degraded = true
    end
  end

  -- 中等检查（每 100 轮）
  if M.loop_count % M.PULSE_MEDIUM == 0 then
    -- 磁盘
    local disk = check_disk()
    if disk == "critical" then
      proactive_exit("disk_full")
      return
    end

    -- 文件描述符
    local fd = check_fd_leak()
    if fd == "exit" then
      proactive_exit("fd_leak")
      return
    end

    -- 网络
    check_network()
  end

  -- 深度检查（每 1000 轮）
  if M.loop_count % M.PULSE_DEEP == 0 then
    -- 通用运行时健康检查；不干预当前前台 App。
    check_runtime_health()

    -- 电量
    check_power()

    -- MemoryGuard 三级保护
    if _G.MemoryGuard and type(_G.MemoryGuard.check) == "function" then
      pcall(_G.MemoryGuard.check)
    end

    -- 强制 GC
    collectgarbage("collect")

    -- 写入健康心跳
    write_health_log("deep_check", string.format("rss=%d status=%s", get_rss_mb(), M.health_status))
  end

  -- 预防性释放/降级（每 10000 轮，不重启 VM）
  if M.loop_count % M.PULSE_REBOOT == 0 then
    local rss = get_rss_mb()
    if rss > 100 then
      proactive_exit("proactive_restart_rss=" .. tostring(rss))
    else
      -- RSS 未知也可做清理，但不宣称内存正常或恢复。
      collectgarbage("collect")
      if type(_G.keepScreen) == "function" then pcall(_G.keepScreen, false) end
      write_health_log("proactive_cleanup", string.format("rss=%d", rss))
    end
  end
end

---------------------------------------------------------------------------
-- 记录找色耗时（供 ThermalGuard 使用）
---------------------------------------------------------------------------
function M.record_find_time(ms)
  M._last_find_ms = tonumber(ms) or 0
end

-- 记录找色结果（供冷却期判断）
function M.record_find_result(found)
  if found then
    M._no_find_count = 0
  else
    M._no_find_count = M._no_find_count + 1
  end
end

---------------------------------------------------------------------------
-- 安装：Hook toast + 初始化
---------------------------------------------------------------------------
function M.install()
  -- require/dofile 重载时复用已安装实例，保持 Hook 闭包与健康状态一致。
  local installed = _G.HealthMonitor
  if _G.__ZIYAN_HEALTH_MONITOR and type(installed) == "table"
      and installed.name == M.name then
    return installed
  end
  M.start_time = os.time()
  M.loop_count = 0
  M.health_status = "ok"
  -- Hook toast 实现智能抑制
  if type(_G.toast) == "function" and not _G.__ZIYAN_TOAST_HOOKED then
    _original_toast = _G.toast
    _G.toast = smart_toast
    _G.__ZIYAN_TOAST_HOOKED = true
  end

  -- Hook findMultiColorInRegionFuzzy 记录耗时
  if type(_G.findMultiColorInRegionFuzzy) == "function" and not _G.__ZIYAN_FIND_HOOKED then
    local _orig_find = _G.findMultiColorInRegionFuzzy
    _G.findMultiColorInRegionFuzzy = function(...)
      local t0 = os.clock()
      local x, y = _orig_find(...)
      local elapsed = (os.clock() - t0) * 1000
      M.record_find_time(elapsed)
      M.record_find_result(x ~= nil and x ~= -1)
      return x, y
    end
    _G.__ZIYAN_FIND_HOOKED = true
  end

  _G.HealthMonitor = M
  _G.__ZIYAN_HEALTH_MONITOR = M.version

  write_health_log("init", "HealthMonitor started")
  return M
end

-- 获取健康摘要
function M.summary()
  local rss = get_rss_mb()
  local fd = get_fd_count()
  return {
    ts = os.time(),
    loop = M.loop_count,
    rss = rss,
    rss_valid = rss > 0,
    status = M.health_status,
    uptime_sec = os.time() - M.start_time,
    find_ms = M._last_find_ms,
    no_find = M._no_find_count,
    cycle_ms = M._cycle_ms,
    degraded = M._degraded,
    net_offline = M._net_offline_mode,
    fd_count = fd,
    fd_valid = fd >= 0,
    disk_pct = get_disk_usage_pct(),
    battery = get_battery_pct(),
    charging = is_charging(),
    -- 缓存读取，不调用 provider、不推进 sample_seq 或连续滞回。
    thermal_raw = system_thermal.raw,
    thermal_valid = system_thermal.valid,
    thermal_source = system_thermal.source,
    thermal_state = system_thermal.state,
    thermal_sample_seq = system_thermal.sample_seq,
    thermal_streak = system_thermal.streak,
    thermal_hold = thermal_hold,
    thermal_freshness = thermal_freshness,
    thermal_activation = thermal_activation,
    thermal_release_status = thermal_release_status,
    thermal_release_return = thermal_release_return,
    thermal_frame_reclaimed = "UNVERIFIED",
  }
end

return M
