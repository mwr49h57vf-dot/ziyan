--[[ HotUpdateGate — 热更新时机门控（需求书 §四）

  只允许两个合法检测时机：
    1. 用户冷启动打开 ZiYan；
    2. App 位于前台，且连续 idle_duration 秒没有用户触摸/输入/交互。

  严格禁止（本模块用状态机强制，而不是靠调用方自觉）：
    · 用户点击/输入/滑动/操作期间检测更新；
    · 用户操作期间下载更新包；
    · 前台使用期间安装更新；
    · 通过后台定时器持续轮询；
    · 未校验包完整性就安装。

  设计要点：
  · 无定时器、无轮询。检测只由「冷启动」或「一次性延迟检查（one-shot）」
    两个事件点触发；期间任何交互都会把状态打回 idle 计数并取消后续动作。
  · 状态持久化到 var_dir()/.ziyan_ui_state，宿主（ObjC）只写两个事实：
      foreground=0|1  和  last_interaction=<unix ts>
    其余判定全部在 Lua 侧完成，便于单测与设备侧复核。
]]

local M = { name = "HotUpdateGate", version = "1.0.0" }

M.DEFAULT_IDLE_SEC = 300

local function var_dir()
  return _G.ZIYAN_VAR or "/usr/lib/ziyan/var"
end

function M.state_path()
  return var_dir() .. "/.ziyan_ui_state"
end

local function trim(s)
  return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

---------------------------------------------------------------------------
-- 状态读写
---------------------------------------------------------------------------

--- 读取 UI 状态。缺失时按「未知」返回，绝不假装在前台。
--- @return table { foreground=bool|nil, last_interaction=number|nil, raw=string }
function M.read_state()
  local f = io.open(M.state_path(), "r")
  if not f then return { foreground = nil, last_interaction = nil, raw = "" } end
  local body = f:read("*a") or ""
  f:close()
  local fg = body:match("foreground=(%d)")
  local li = body:match("last_interaction=(%d+)")
  -- 注意 Lua 三元陷阱：`cond and false or nil` 在 cond 为真时仍得到 nil，
  -- 会把「明确的后台(false)」误判成「未知(nil)」。必须显式分支。
  local foreground = nil
  if fg == "1" then foreground = true elseif fg == "0" then foreground = false end
  return {
    foreground = foreground,
    last_interaction = tonumber(li),
    raw = body,
  }
end

local function write_state(fg, last_interaction)
  local path = M.state_path()
  local dir = path:match("^(.*)/[^/]+$")
  if dir then
    -- var_dir 通常已存在；缺失时尽力创建，失败则由调用方感知（返回 false）
    local probe = io.open(dir .. "/.gate_probe", "w")
    if probe then
      probe:close()
      os.remove(dir .. "/.gate_probe")
    else
      os.execute(string.format("mkdir -p '%s' 2>/dev/null", dir))
    end
  end
  local tmp = path .. ".tmp"
  local f = io.open(tmp, "w")
  if not f then return false end
  local body = string.format("foreground=%d\nlast_interaction=%d\nupdated=%d\n",
    fg and 1 or 0, tonumber(last_interaction) or 0, os.time())
  local wrote = f:write(body)
  local closed = f:close()
  if not wrote or not closed then os.remove(tmp); return false end
  local renamed = os.rename(tmp, path)
  if not renamed then os.remove(tmp) end
  return renamed and true or false
end

---------------------------------------------------------------------------
-- 宿主写入接口（ObjC 触摸 / 前后台切换）
---------------------------------------------------------------------------

--- 记录一次用户交互（触摸/输入）。下载期间被调用 → 后续动作必须停止。
function M.mark_interaction(now)
  local st = M.read_state()
  local fg = st.foreground == true
  local ok = write_state(fg, tonumber(now) or os.time())
  M._last_mark = { ts = tonumber(now) or os.time(), ok = ok }
  return ok
end

--- 前台/后台切换
function M.set_foreground(value, now)
  local fg = value == true
  local st = M.read_state()
  local li = st.last_interaction
  -- 回到前台时把交互时间刷新到现在：避免「后台待了很久」被误判成 idle 达标，
  -- 用户刚回到前台不应立刻触发更新。
  if fg then li = tonumber(now) or os.time() end
  return write_state(fg, li or (tonumber(now) or os.time()))
end

function M.foreground()
  return M.read_state().foreground
end

function M.idle_seconds(now)
  local st = M.read_state()
  local li = st.last_interaction
  if not li then return nil end
  return math.max(0, (tonumber(now) or os.time()) - li)
end

function M.idle_duration()
  return tonumber(M._idle_sec) or M.DEFAULT_IDLE_SEC
end

function M.set_idle_duration(sec)
  local v = tonumber(sec)
  if v and v > 0 then M._idle_sec = v end
  return M.idle_duration()
end

---------------------------------------------------------------------------
-- 判定
---------------------------------------------------------------------------

--- 是否允许「检测更新」。
--- 条件：必须在前台（后台不得检测），且连续 idle >= idle_duration。
--- 未知前台状态一律拒绝（fail-closed）。
--- @return boolean, string reason
function M.can_detect(now)
  local st = M.read_state()
  if st.foreground == nil then return false, "foreground_unknown" end
  if st.foreground ~= true then return false, "not_foreground" end
  local li = st.last_interaction
  if not li then return false, "interaction_unknown" end
  local idle = math.max(0, (tonumber(now) or os.time()) - li)
  if idle < M.idle_duration() then
    return false, string.format("user_active:idle=%ds<need=%ds", idle, M.idle_duration())
  end
  return true, "idle_ok"
end

--- 是否允许「下载更新包」。
--- 与检测同源：交互一旦发生就必须停（调用方负责在下载循环中周期性复查）。
function M.can_download(now)
  return M.can_detect(now)
end

--- 是否允许「安装更新」。
--- 需求书 §四.8：安装必须等 App 进入后台后执行 → 前台一律拒绝。
--- @return boolean, string reason
function M.can_install(now)
  local st = M.read_state()
  if st.foreground == nil then return false, "foreground_unknown" end
  if st.foreground == true then return false, "foreground_forbidden" end
  return true, "background_ok"
end

--- 冷启动是唯一无需 idle 的检测时机（用户刚打开 App）。
--- 但依然要求 App 处于前台。
function M.can_detect_on_cold_start(now)
  local st = M.read_state()
  if st.foreground == nil then return false, "foreground_unknown" end
  if st.foreground ~= true then return false, "not_foreground" end
  return true, "cold_start_ok"
end

---------------------------------------------------------------------------
-- 一次性延迟检查（替代「后台定时器持续轮询」）
---------------------------------------------------------------------------

--- 计划一次 one-shot 检查：在 delay_sec 后复查 can_detect。
--- 返回一个 ticket 表；调用方在等待期间每次用户交互都应调用 M.cancel(ticket)。
--- 本函数不注册任何定时器 —— 由宿主在合适的时机（如主循环空转）驱动 M.poll。
function M.plan(opts)
  opts = type(opts) == "table" and opts or {}
  local now = tonumber(opts.now) or os.time()
  return {
    created = now,
    due = now + (tonumber(opts.delay_sec) or M.idle_duration()),
    cancelled = false,
    reason = nil,
  }
end

function M.cancel(ticket, reason)
  if type(ticket) == "table" then
    ticket.cancelled = true
    ticket.reason = tostring(reason or "cancelled")
  end
  return ticket
end

--- 单一检查点：ticket 到期且期间无交互 → 允许；否则给出原因。
--- @return boolean, string
function M.poll(ticket, now)
  if type(ticket) ~= "table" then return false, "no_ticket" end
  if ticket.cancelled then return false, ticket.reason or "cancelled" end
  local t = tonumber(now) or os.time()
  if t < ticket.due then return false, "not_due" end
  return M.can_detect(t)
end

function M.install_module()
  _G.HotUpdateGate = M
  _G.__ZIYAN_HOTUPDATE_GATE = M.version
  return M
end

return M
