--[[ HotUpdateGithub — 热更新 GitHub Raw 取源（需求书 §四）

  与 HotUpdate.lua 的分工：
    · 本模块只负责「取源 + 严格解析 version.txt + 下载（含 Range 断点续传）」；
    · 安装 / 健康检查 / 回滚 / 事务 仍完全复用 HotUpdate.install / health_check /
      rollback / transaction，本模块不重复实现，也不改其语义。

  取源固定为公开 GitHub Raw：
    <raw_base>/version.txt
    <raw_base>/packages/<version>/<package-file>

  version.txt 严格格式（缺字段/未知键/非法值一律拒绝，不静默兜底）：
    version=...
    sha256=...
    size=...
    architecture=...
    min_os=...
    max_os=...
    channel=stable

  标签纪律：本模块的传输层在无 HTTPS 通道的设备上必须如实返回
  `transport_unavailable`，不得伪造成功。
]]

local M = { name = "HotUpdateGithub", version = "1.0.0" }

M.REQUIRED_KEYS = {
  "version", "sha256", "size", "architecture", "min_os", "max_os", "channel",
}
M.DEFAULT_RAW_BASE =
  "https://raw.githubusercontent.com/mwr49h57vf-dot/ziyan/gh-pages"
M.DEFAULT_IDLE_SEC = 300

local function trim(s)
  return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end

local ZS = (function()
  local ok, mod = pcall(require, "zy_shell")
  if ok and type(mod) == "table" and type(mod.run_capture_status) == "function" then
    return mod
  end
  local base = _G.ZIYAN_LUA or "/usr/lib/ziyan/lib/lua"
  for _, path in ipairs({
    base .. "/modules/zy_shell.lua",
    "/var/jb/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
    "/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
  }) do
    local f = io.open(path, "r")
    if f then
      f:close()
      local loaded, candidate = pcall(dofile, path)
      if loaded and type(candidate) == "table"
          and type(candidate.run_capture_status) == "function" then
        return candidate
      end
    end
  end
  return nil
end)()
-- 必须用 *_status 入口：run_capture 只返回 body（单值），
-- 拿它当退出码会恒为 nil，导致「命令成功却被判失败」。
local run_capture = ZS and ZS.run_capture_status or function() return "", 1 end

---------------------------------------------------------------------------
-- 严格解析 version.txt
---------------------------------------------------------------------------

--- 解析 version.txt 文本。
--- @return table|nil info, string|nil reason
--- 拒绝条件：空、缺必需键、未知键、重复键、非法 sha256/size、
---           architecture/min_os/max_os/channel 为空。
function M.parse_version_txt(text)
  if type(text) ~= "string" or trim(text) == "" then
    return nil, "version_txt_empty"
  end
  local seen, fields = {}, {}
  for raw_line in text:gmatch("[^\r\n]+") do
    local line = trim(raw_line)
    if line ~= "" and line:sub(1, 1) ~= "#" then
      local key, value = line:match("^([%w_]+)%s*=%s*(.-)%s*$")
      if not key then
        return nil, "version_txt_bad_line:" .. line:sub(1, 40)
      end
      if seen[key] then return nil, "version_txt_duplicate_key:" .. key end
      seen[key] = true
      fields[key] = value
    end
  end
  for _, key in ipairs(M.REQUIRED_KEYS) do
    if not seen[key] then return nil, "version_txt_missing:" .. key end
    if fields[key] == nil or fields[key] == "" then
      return nil, "version_txt_empty_value:" .. key
    end
  end
  for key in pairs(fields) do
    local known = false
    for _, k in ipairs(M.REQUIRED_KEYS) do
      if k == key then known = true break end
    end
    if not known then return nil, "version_txt_unknown_key:" .. key end
  end
  if not fields.sha256:match("^%x+$") or #fields.sha256 ~= 64 then
    return nil, "version_txt_bad_sha256"
  end
  local size = tonumber(fields.size)
  if not size or size <= 0 or size ~= math.floor(size) then
    return nil, "version_txt_bad_size"
  end
  if not fields.version:match("^%d[%w%.%+%-%:~]*$") then
    return nil, "version_txt_bad_version"
  end
  -- 注意 Lua 模式的 ? 只作用于前一个字符：`arm64?` 会被解析成 arm6 + 可选 4，
  -- 导致 "iphoneos-arm" 被误判为非法。必须显式枚举两种合法架构。
  if fields.architecture ~= "iphoneos-arm"
      and fields.architecture ~= "iphoneos-arm64" then
    return nil, "version_txt_bad_architecture"
  end
  if not fields.min_os:match("^%d+%.%d+") or not fields.max_os:match("^%d+%.%d+") then
    return nil, "version_txt_bad_os_range"
  end
  if fields.channel ~= "stable" and fields.channel ~= "beta" then
    return nil, "version_txt_bad_channel"
  end
  return {
    version = fields.version,
    sha256 = fields.sha256:lower(),
    size = size,
    architecture = fields.architecture,
    min_os = fields.min_os,
    max_os = fields.max_os,
    channel = fields.channel,
  }
end

--- 由 version/sha256 推导包绝对 URL（§四 固定布局）
function M.package_url(raw_base, info)
  local base = tostring(raw_base or M.DEFAULT_RAW_BASE):gsub("/+$", "")
  return string.format("%s/packages/%s/%s-%s.deb", base, info.version,
    info.architecture, info.sha256)
end

---------------------------------------------------------------------------
-- 传输层：多通道探测，全部不可用时如实返回 transport_unavailable
---------------------------------------------------------------------------

local function tmp_dir()
  for _, d in ipairs({ _G.ZIYAN_VAR, "/tmp",
      _G.ZIYAN_ZYCV and (_G.ZIYAN_ZYCV .. "/tmp") or nil }) do
    if d then
      local probe = io.open(d .. "/.zy_hug_probe", "w")
      if probe then probe:close(); os.remove(d .. "/.zy_hug_probe"); return d end
    end
  end
  return "/tmp"
end

--- 探测可用的 HTTPS 通道。
--- 返回 (kind, path)：kind = "curl" | "python3" | nil
--- 缓存探测结果，避免每次请求都重跑。
function M.detect_transport(force)
  if M._transport ~= nil and not force then return M._transport end
  local kind, path = nil, nil
  for _, c in ipairs({ "/var/jb/usr/bin/curl", "/usr/bin/curl",
      "/usr/local/bin/curl", "/bin/curl" }) do
    local f = io.open(c, "r")
    if f then f:close(); kind, path = "curl", c break end
  end
  if not kind then
    for _, p in ipairs({ "/var/jb/usr/lib/ziyan/bin/python3.7",
        "/usr/lib/ziyan/bin/python3.7", "/usr/bin/python3" }) do
      local f = io.open(p, "r")
      if f then f:close(); kind, path = "python3", p break end
    end
  end
  M._transport = { kind = kind, path = path }
  return M._transport
end

--- python3 在本机布局下需要 DYLD 前缀（rootless 实测）
local function py_env_prefix(py)
  if type(py) ~= "string" or py:sub(1, 7) ~= "/var/jb" then return "" end
  local dir = "/var/jb/usr/lib/ziyan/lib"
  local f = io.open(dir .. "/libpython3.7m.dylib", "r")
  if not f then return "" end
  f:close()
  return "DYLD_LIBRARY_PATH=" .. dir .. " "
end

--- 生成 python HTTPS 取数脚本（写盘一次，复用）
local function ensure_py_helper()
  local p = tmp_dir() .. "/.zy_hug_fetch.py"
  local f = io.open(p, "r")
  if f then
    local head = f:read(120) or ""
    f:close()
    if head:find("zy_hug_v2_range", 1, true) then return p end
  end
  local h = io.open(p, "w")
  if not h then return nil end
  h:write([[
# zy_hug_v2_range
import sys, ssl, socket, os
url, out, off = sys.argv[1], sys.argv[2], int(sys.argv[3])
assert url.startswith("https://")
rest = url[len("https://"):]
host, _, path = rest.partition("/")
path = "/" + path
ctx = ssl.create_default_context()
s = ctx.wrap_socket(socket.create_connection((host, 443), timeout=25),
                    server_hostname=host)
rng = ("Range: bytes=%d-\r\n" % off) if off > 0 else ""
s.sendall(("GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: ziyan-hotupdate\r\n%s\r\n"
           % (path, host, rng)).encode())
buf = b""
while b"\r\n\r\n" not in buf:
    chunk = s.recv(4096)
    if not chunk: break
    buf += chunk
head, _, body = buf.partition(b"\r\n\r\n")
status = head.split(b"\r\n")[0].decode(errors="replace")
code = int(status.split()[1]) if len(status.split()) > 1 else 0
mode = "wb" if off == 0 else "ab"
with open(out, mode) as f:
    f.write(body)
    while True:
        chunk = s.recv(65536)
        if not chunk: break
        f.write(chunk)
s.close()
sys.stderr.write("STATUS=%s\n" % status)
sys.exit(0 if code in (200, 206) else 3)
]])
  h:close()
  return p
end

--- 取 version.txt 文本（小文件，直接读 body）
--- @return string|nil body, string|nil reason
function M.fetch_text(url, timeout)
  local t = tonumber(timeout) or 20
  local tr = M.detect_transport()
  if not tr.kind then return nil, "transport_unavailable" end
  if tr.kind == "curl" then
    local out = tmp_dir() .. "/.zy_hug_get.txt"
    os.remove(out)
    run_capture(string.format(
      "DYLD_LIBRARY_PATH= '%s' -sSL --max-time %d -o '%s' '%s'",
      tr.path, t, out, url))
    local f = io.open(out, "r")
    if not f then return nil, "transport_fetch_failed" end
    local body = f:read("*a") or ""
    f:close()
    os.remove(out)
    if body == "" then return nil, "transport_empty_response" end
    return body
  end
  -- python3 通道
  local helper = ensure_py_helper()
  if not helper then return nil, "helper_write_failed" end
  local out = tmp_dir() .. "/.zy_hug_get_py.txt"
  os.remove(out)
  local _, code = run_capture(string.format(
    "%s'%s' '%s' '%s' '%s' 0 2>&1", py_env_prefix(tr.path), tr.path, helper, url, out))
  local f = io.open(out, "r")
  if not f then return nil, "transport_fetch_failed" end
  local body = f:read("*a") or ""
  f:close()
  if code ~= 0 or body == "" then return nil, "transport_fetch_failed" end
  return body
end

--- 下载到 dest，支持 HTTP Range 断点续传（§四.5）。
--- 已存在部分文件时从已有长度续传；完成后由调用方校验 size/sha256。
--- @return boolean ok, number|string bytes_or_reason
function M.download_range(url, dest, timeout)
  local t = tonumber(timeout) or 180
  local tr = M.detect_transport()
  if not tr.kind then return false, "transport_unavailable" end
  local have = 0
  local f = io.open(dest, "rb")
  if f then have = f:seek("end") or 0; f:close() end
  if tr.kind == "curl" then
    local resume = have > 0 and string.format("--continue-at %d ", have) or ""
    local _, code = run_capture(string.format(
      "DYLD_LIBRARY_PATH= '%s' -sSL --max-time %d %s-o '%s' '%s'",
      tr.path, t, resume, dest, url))
    if code ~= 0 then return false, "download_failed:" .. tostring(code) end
    return true, dest
  end
  local helper = ensure_py_helper()
  if not helper then return false, "helper_write_failed" end
  local _, code = run_capture(string.format(
    "%s'%s' '%s' '%s' '%s' %d 2>&1",
    py_env_prefix(tr.path), tr.path, helper, url, dest, have))
  if code ~= 0 then return false, "download_failed:" .. tostring(code) end
  return true, dest
end

---------------------------------------------------------------------------
-- 配置
---------------------------------------------------------------------------

function M.raw_base()
  if type(_G.ZIYAN_HOTUPDATE_RAW_BASE) == "string"
      and #_G.ZIYAN_HOTUPDATE_RAW_BASE > 0 then
    return _G.ZIYAN_HOTUPDATE_RAW_BASE
  end
  local root = _G.ZIYAN_ZYCV or "/private/var/mobile/Media/ZiYan/ZYCV"
  local f = io.open(root .. "/config/hotupdate_github.txt", "r")
  if f then
    local body = trim((f:read("*a") or ""):match("^([^\n]*)") or "")
    f:close()
    if #body > 0 then return body end
  end
  return M.DEFAULT_RAW_BASE
end

---------------------------------------------------------------------------
-- 检查更新
---------------------------------------------------------------------------

--- 读取 version.txt → 解析 → 客户端二次兼容性校验 → 版本比较。
--- @return table|nil info, string|nil reason
function M.check(opts)
  opts = type(opts) == "table" and opts or {}
  local base = opts.raw_base or M.raw_base()
  local url = base:gsub("/+$", "") .. "/version.txt"
  local body, ferr = M.fetch_text(url, opts.timeout)
  if not body then return nil, ferr end
  local info, perr = M.parse_version_txt(body)
  if not info then return nil, perr end
  info.raw_base = base
  info.url = M.package_url(base, info)

  -- 客户端二次兼容性闸：复用 HotUpdate（不重写规则）
  local H = opts.hotupdate or _G.HotUpdate
  if type(H) ~= "table" or type(H.compatible) ~= "function" then
    return info, "hotupdate_module_missing"
  end
  local cok, why = H.compatible({
    architecture = info.architecture,
    min_os = info.min_os,
    max_os = info.max_os,
  }, opts)
  if not cok then
    info.update = false
    return info, "device_incompatible:" .. tostring(why)
  end

  -- 版本比较：Debian 规则（HotUpdate.is_newer → dpkg --compare-versions）
  local installed, ierr = H.installed_state()
  if not installed then return info, ierr or "installed_state_unavailable" end
  info.installed_version = installed.version
  if type(H.is_newer) ~= "function" then return info, "is_newer_missing" end
  local newer, cmp = H.is_newer(info.version, installed.version)
  if not newer then
    info.update = false
    return info, cmp or "no_update"
  end
  info.update = true
  return info, nil
end

function M.install_module()
  _G.HotUpdateGithub = M
  _G.__ZIYAN_HOTUPDATE_GITHUB = M.version
  return M
end

return M
