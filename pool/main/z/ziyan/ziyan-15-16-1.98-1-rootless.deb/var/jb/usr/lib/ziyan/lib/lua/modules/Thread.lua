--[[ Zy.Thread — 协作式线程（单 Lua 状态机；非 OS 真线程）
  Division2 Wave4：对齐 TS thread.* 契约名；禁止阻塞 SB 主线程（本模块仅在 lua 进程）。
  风险：create 内死循环无 mSleep/wait 会饿死调度；勿在回调里狂截屏。
]]
local M = { name = "Thread", version = "1.0.0" }

local _next = 1
local _jobs = {} -- id -> { co, alive, running }; terminal records are unlinked
local _timeouts = {} -- id -> { at, fn, alive }
local _tid = 1

-- Issued IDs are recognized by counters, never by retained terminal records.
local function issued_id(id, next_id)
  id = tonumber(id)
  if id and id >= 1 and id < next_id and id % 1 == 0 then return id end
end

local function retire_job(id, j)
  if _jobs[id] == j then _jobs[id] = nil end
  j.alive, j.co, j.err, j.running = false, nil, nil, nil
end

local function sleep_ms(ms)
  ms = tonumber(ms) or 0
  if ms <= 0 then return end
  if type(_G.mSleep) == "function" then
    mSleep(ms)
  else
    local n = os.clock() + ms / 1000
    while os.clock() < n do end
  end
end

local function now_ms()
  return (os.time() * 1000) + math.floor((os.clock() % 1) * 1000)
end

function M._pump_timeouts()
  local t = now_ms()
  local pending = {}
  for id, to in pairs(_timeouts) do
    if to.alive then pending[#pending + 1] = { id, to } end
  end
  for _, entry in ipairs(pending) do
    local id, to = entry[1], entry[2]
    if _timeouts[id] == to and to.alive and t >= to.at then
      _timeouts[id] = nil
      local fn = to.fn
      to.alive, to.fn = false, nil
      pcall(fn)
    end
  end
end

function M._resume(id)
  local j = _jobs[id]
  if not j or not j.alive or j.running then return false end
  local co = j.co
  local status = coroutine.status(co)
  if status == "dead" then
    retire_job(id, j)
    return false
  end
  if status ~= "suspended" then return false end
  j.running = true
  local ok, a = coroutine.resume(co)
  if not ok or coroutine.status(co) == "dead" then
    retire_job(id, j)
    return false
  end
  if _jobs[id] ~= j or not j.alive then return false end
  if type(a) == "number" and a > 0 then
    local slept, err = pcall(sleep_ms, a)
    j.running = nil
    if not slept then error(err, 0) end
  else
    j.running = nil
  end
  if _jobs[id] ~= j then return false end
  return j.alive
end

--- 创建协作线程；返回 id
function M.create(fn)
  if type(fn) ~= "function" then return nil, "need_function" end
  local id = _next
  _next = _next + 1
  local co = coroutine.create(function()
    fn()
  end)
  _jobs[id] = { co = co, alive = true, err = nil }
  M._resume(id)
  return id
end

function M.createSubThread(fn)
  return M.create(fn)
end

--- 当前协作上下文等待；主线程则 mSleep
function M.wait(ms)
  ms = tonumber(ms) or 0
  local co, is_main = coroutine.running()
  if co and not is_main then
    return coroutine.yield(ms)
  end
  sleep_ms(ms)
  M._pump_timeouts()
  return true
end

function M.setTimeout(ms, fn)
  if type(fn) ~= "function" then return nil, "need_function" end
  local id = _tid
  _tid = _tid + 1
  _timeouts[id] = { at = now_ms() + (tonumber(ms) or 0), fn = fn, alive = true }
  return id
end

function M.clearTimeout(id)
  id = issued_id(id, _tid)
  if not id then return false end
  local to = _timeouts[id]
  if to then
    _timeouts[id] = nil
    to.alive, to.fn = false, nil
  end
  return true
end

function M.stop(id)
  id = issued_id(id, _next)
  if not id then return false end
  local j = _jobs[id]
  if j then retire_job(id, j) end
  return true
end

--- Advance cooperative jobs and timers; retain the existing bounded step policy.
function M.waitAllThreadExit(max_steps)
  max_steps = tonumber(max_steps) or 10000
  for _ = 1, max_steps do
    M._pump_timeouts()
    local any = false
    local pending = {}
    for id, j in pairs(_jobs) do
      if j.alive then pending[#pending + 1] = { id, j } end
    end
    for _, entry in ipairs(pending) do
      local id, j = entry[1], entry[2]
      -- Nested pumps may detach a record; only its current identity is resumable.
      if _jobs[id] == j and j.alive then
        any = true
        if not j.running then M._resume(id) end
      end
    end
    if not any then return true end
    sleep_ms(10)
  end
  return false, "timeout_steps"
end

return M
