--[[ Zy.Touch — 触控模块
  点击坐标统一按逻辑屏坐标原样交给全局 tap；设计/比例入口只负责
  先把坐标换算到逻辑屏。找色、找图、找字返回的 x,y 与固定整数
  tap(x,y) 使用同一个直通入口，不再因参数来源不同而拒绝。
]]
local C = require("modules._ctx")
local M = { name = "Touch", version = "1.0.0" }

local function defined(n) return type(_G[n]) == "function" end

local function invoke(name, ...)
  if not defined(name) then return false end
  local ok, result = pcall(_G[name], ...)
  return ok and result ~= false
end

local function tap_logic(lx, ly, hold_ms)
  if defined("tap") then
    if hold_ms then return tap(lx, ly, hold_ms) end
    return tap(lx, ly)
  end
  if defined("touchDown") and defined("touchUp") then
    local okd = invoke("touchDown", 1, lx, ly)
    if okd and defined("mSleep") then mSleep(hold_ms or 70) end
    local oku = invoke("touchUp", 1, lx, ly)
    return (okd and oku) or false
  end
  return false, lx, ly
end

--- 设计坐标点击（推荐）
function M.tapDesign(dx, dy, hold_ms)
  C.require_pipeline("touch")
  local Coord = require("modules.Coordinate")
  local lx, ly = Coord.point(dx, dy)
  return tap_logic(lx, ly, hold_ms), lx, ly
end

--- 比例点击 0~1
function M.tapRatio(rx, ry, hold_ms)
  C.require_pipeline("touch")
  local Coord = require("modules.Coordinate")
  local lx, ly = Coord.ratio(rx, ry)
  return tap_logic(lx, ly, hold_ms), lx, ly
end

--- 视觉命中点点击（逻辑点来自 Image/OCR，非手写死坐标）
function M.tapHit(lx, ly, hold_ms)
  C.require_pipeline("touch")
  lx, ly = tonumber(lx), tonumber(ly)
  if not lx or not ly or lx < 0 or ly < 0 then
    return false, "bad_hit"
  end
  return tap_logic(lx, ly, hold_ms), lx, ly
end

--- 原始逻辑坐标点击：固定整数和视觉命中坐标都原样执行
function M.tap(x, y, ...)
  C.require_pipeline("touch")
  x, y = tonumber(x), tonumber(y)
  if x == nil or y == nil then
    return false, "bad_args"
  end
  local hold_ms = select(1, ...)
  local ok = tap_logic(x, y, hold_ms)
  return ok, x, y
end

local function sleep(ms)
  if defined("mSleep") then mSleep(ms or 0) end
end

local function finite_number(value, fallback)
  value = tonumber(value)
  return value or fallback
end

local function jitter(value, radius)
  return value + math.random(-radius, radius)
end

local function swipe_logic(x1, y1, x2, y2, duration_ms)
  if not (defined("touchDown") and defined("touchMove") and defined("touchUp")) then
    return false, "no_gesture_api"
  end
  local distance = math.max(math.abs(x2 - x1), math.abs(y2 - y1), 1)
  local steps = math.max(1, math.floor(distance / 20))
  local step_ms = math.max(1, math.floor(duration_ms / steps))
  local ok = invoke("touchDown", 1, x1, y1)
  local x, y = x1, y1
  for i = 1, steps do
    if not ok then break end
    local t = i / steps
    x, y = x1 + (x2 - x1) * t, y1 + (y2 - y1) * t
    ok = invoke("touchMove", 1, x, y)
    if ok then sleep(step_ms) end
  end
  local up = invoke("touchUp", 1, x, y)
  return ok and up
end

--- 比例滑动 0~1（推荐；禁止固定物理坐标）
function M.swipeRatio(rx1, ry1, rx2, ry2, steps, step_ms)
  C.require_pipeline("touch")
  local Coord = require("modules.Coordinate")
  local x1, y1 = Coord.ratio(rx1, ry1)
  local x2, y2 = Coord.ratio(rx2, ry2)
  steps = math.max(1, tonumber(steps) or 12)
  step_ms = tonumber(step_ms) or 16
  if defined("touchDown") and defined("touchMove") and defined("touchUp") then
    local ok = invoke("touchDown", 1, x1, y1)
    local x, y = x1, y1
    for i = 1, steps do
      if not ok then break end
      local t = i / steps
      x = x1 + (x2 - x1) * t
      y = y1 + (y2 - y1) * t
      ok = invoke("touchMove", 1, x, y)
      if ok then sleep(step_ms) end
    end
    local up = invoke("touchUp", 1, x, y)
    return ok and up, x1, y1, x2, y2
  end
  return false, "no_gesture_api"
end

--- 手势链：比例点序列 { {rx,ry}, ... }
function M.gesture(points, step_ms)
  C.require_pipeline("touch")
  points = points or {}
  if #points < 2 then return false, "need_2_points" end
  local Coord = require("modules.Coordinate")
  step_ms = tonumber(step_ms) or 20
  local pts = {}
  for i, p in ipairs(points) do
    local rx = tonumber(p.rx or p[1])
    local ry = tonumber(p.ry or p[2])
    local lx, ly = Coord.ratio(rx, ry)
    pts[i] = { lx, ly }
  end
  if not (defined("touchDown") and defined("touchMove") and defined("touchUp")) then
    return false, "no_gesture_api"
  end
  local ok = invoke("touchDown", 1, pts[1][1], pts[1][2])
  local last = pts[1]
  for i = 2, #pts do
    if not ok then break end
    last = pts[i]
    ok = invoke("touchMove", 1, last[1], last[2])
    if ok then sleep(step_ms) end
  end
  local up = invoke("touchUp", 1, last[1], last[2])
  return ok and up
end

--- 设计坐标长按（hold_ms 默认 800）
function M.longPress(dx, dy, hold_ms)
  return M.tapDesign(dx, dy, tonumber(hold_ms) or 800)
end

--- 比例长按（0~1；避免调用方使用物理坐标）
function M.longPressRatio(rx, ry, hold_ms)
  return M.tapRatio(rx, ry, tonumber(hold_ms) or 800)
end

--- 短别名：比例滑动（同 swipeRatio）
M.swipe = M.swipeRatio

--- 多指按下（finger id 1..9；设计坐标）
function M.fingerDown(id, dx, dy)
  C.require_pipeline("touch")
  local Coord = require("modules.Coordinate")
  local lx, ly = Coord.point(dx, dy)
  id = math.max(1, math.min(9, tonumber(id) or 1))
  if defined("touchDown") then
    return invoke("touchDown", id, lx, ly), lx, ly
  end
  return false, lx, ly
end

function M.fingerMove(id, dx, dy)
  C.require_pipeline("touch")
  local Coord = require("modules.Coordinate")
  local lx, ly = Coord.point(dx, dy)
  id = math.max(1, math.min(9, tonumber(id) or 1))
  if defined("touchMove") then
    return invoke("touchMove", id, lx, ly), lx, ly
  end
  return false, lx, ly
end

function M.fingerUp(id, dx, dy)
  C.require_pipeline("touch")
  local Coord = require("modules.Coordinate")
  local lx, ly = Coord.point(dx, dy)
  id = math.max(1, math.min(9, tonumber(id) or 1))
  if defined("touchUp") then
    return invoke("touchUp", id, lx, ly), lx, ly
  end
  return false, lx, ly
end

--- 双指捏合（设计坐标中心 + 起止半径）
function M.pinch(cx, cy, r0, r1, steps, step_ms)
  C.require_pipeline("touch")
  steps = math.max(2, tonumber(steps) or 10)
  step_ms = tonumber(step_ms) or 20
  r0, r1 = tonumber(r0) or 80, tonumber(r1) or 20
  for i = 0, steps do
    local t = i / steps
    local r = r0 + (r1 - r0) * t
    if i == steps then
      local up1 = M.fingerUp(1, cx - r, cy)
      local up2 = M.fingerUp(2, cx + r, cy)
      return up1 and up2
    end
    local phase = i == 0 and M.fingerDown or M.fingerMove
    local ok1 = phase(1, cx - r, cy)
    local ok2 = ok1 and phase(2, cx + r, cy)
    if not (ok1 and ok2) then
      M.fingerUp(1, cx - r, cy)
      M.fingerUp(2, cx + r, cy)
      return false
    end
    sleep(step_ms)
  end
  return true
end

--- 触动兼容：在同一点随机化手指和按压时长，不伪造坐标变化。
function M.randomTap(x, y, ms)
  C.require_pipeline("touch")
  x, y = finite_number(x, 0), finite_number(y, 0)
  ms = finite_number(ms, math.random(80, 140))
  return M.tap(x, y, ms)
end

--- 触动兼容：在起止点附近加入微小抖动后执行一次滑动点击。
function M.randomsTap(x1, y1, x2, y2, ms)
  C.require_pipeline("touch")
  x1, y1 = finite_number(x1, 0), finite_number(y1, 0)
  x2, y2 = finite_number(x2, x1), finite_number(y2, y1)
  local jx1, jy1 = jitter(x1, 2), jitter(y1, 2)
  local jx2, jy2 = jitter(x2, 2), jitter(y2, 2)
  local ok = swipe_logic(jx1, jy1, jx2, jy2, finite_number(ms, 400))
  return ok, jx1, jy1, jx2, jy2
end

--- 触动兼容：按角度和距离从起点滑动。
function M.moveTowards(x, y, angle, distance, step, ms)
  C.require_pipeline("touch")
  x, y = finite_number(x, 0), finite_number(y, 0)
  angle = math.rad(finite_number(angle, 0))
  distance = finite_number(distance, 0)
  local x2 = x + math.cos(angle) * distance
  local y2 = y + math.sin(angle) * distance
  return swipe_logic(x, y, x2, y2, finite_number(ms, 400))
end

--- 触动兼容：沿圆弧滑动。角度单位为度，顺时针方向由起止角度决定。
function M.moveCirclePonits(cx, cy, radius, start_angle, end_angle, steps, ms)
  C.require_pipeline("touch")
  cx, cy = finite_number(cx, 0), finite_number(cy, 0)
  radius = math.max(0, finite_number(radius, 0))
  start_angle = math.rad(finite_number(start_angle, 0))
  end_angle = math.rad(finite_number(end_angle, 360))
  steps = math.max(2, math.floor(finite_number(steps, 20)))
  ms = math.max(1, finite_number(ms, 400))
  local function point(t)
    local a = start_angle + (end_angle - start_angle) * t
    return cx + math.cos(a) * radius, cy + math.sin(a) * radius
  end
  local x1, y1 = point(0)
  if not (defined("touchDown") and defined("touchMove") and defined("touchUp")) then
    return false, "no_gesture_api"
  end
  local ok = invoke("touchDown", 1, x1, y1)
  local x, y = x1, y1
  for i = 1, steps do
    if not ok then break end
    x, y = point(i / steps)
    ok = invoke("touchMove", 1, x, y)
    if ok then sleep(math.max(1, math.floor(ms / steps))) end
  end
  local x2, y2 = point(1)
  local up = invoke("touchUp", 1, x, y)
  return ok and up, x1, y1, x2, y2
end

--- 触动兼容：当前没有可验证的用户触摸捕获回传通道时必须明确失败。
function M.catchTouchPoint(...)
  return false, "unsupported:no_touch_capture_channel"
end

function M.getAngle(x1, y1, x2, y2)
  x1, y1 = finite_number(x1, 0), finite_number(y1, 0)
  x2, y2 = finite_number(x2, 0), finite_number(y2, 0)
  return math.deg(math.atan2(y2 - y1, x2 - x1))
end

return M
