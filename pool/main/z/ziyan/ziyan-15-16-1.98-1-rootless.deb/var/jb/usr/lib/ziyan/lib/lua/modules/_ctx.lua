--[[ modules 内部：管道上下文（非用户 API）
  强制：Device → Screen → Coordinate → Vision → Touch → Verify
]]
local C = {
  bid = nil,
  orient = 1,
  design_w = nil,
  design_h = nil,
  synced = false,
  device_ok = false,
}

function C.reset()
  C.bid, C.orient = nil, 1
  C.design_w, C.design_h = nil, nil
  C.synced, C.device_ok = false, false
end

function C.set_bid(bid)
  if bid then C.bid = bid; _G.__ZIYAN_LAST_BID = bid end
  return C.bid
end

function C.set_design(w, h)
  w, h = tonumber(w), tonumber(h)
  if not w or not h or w < 1 or h < 1 then
    return false, "design_required"
  end
  C.design_w, C.design_h = math.floor(w), math.floor(h)
  return true
end

function C.require_design()
  if not C.design_w or not C.design_h then
    -- 兼容：未 setDesign 时用当前逻辑分辨率，避免图色直接崩
    pcall(function()
      local S = require("modules.Screen")
      local w, h = S.size()
      if tonumber(w) and tonumber(h) and w > 0 and h > 0 then
        C.design_w, C.design_h = math.floor(w), math.floor(h)
      end
    end)
  end
  if not C.design_w or not C.design_h then
    error("Zy.Coordinate: setDesign(w,h) required — fixed physical coords forbidden", 2)
  end
  return C.design_w, C.design_h
end

function C.mark_device()
  C.device_ok = true
end

function C.mark_sync()
  C.synced = true
end

function C.require_pipeline(stage)
  -- 坐标换算和触控不观察前台或帧；视觉入口自行保持原同步检查。
  if stage == "touch" or stage == "coordinate" then return end
  -- stage: device|screen|coordinate|vision|touch|verify
  -- 兼容恢复：未显式 Device.refresh 时自动补一次（不改 API）
  if not C.device_ok then
    pcall(function()
      local D = require("modules.Device")
      if type(D.refresh) == "function" then D.refresh() end
    end)
  end
  if stage == "screen" or stage == "coordinate" or stage == "vision"
      or stage == "touch" or stage == "verify" then
    if not C.device_ok then
      error("Zy pipeline: call Zy.Device.refresh() first", 2)
    end
  end
  if stage == "coordinate" or stage == "vision" or stage == "touch" or stage == "verify" then
    if not C.synced and not C._syncing then
      C._syncing = true
      pcall(function()
        local S = require("modules.Screen")
        if type(S.sync) == "function" then
          S.sync(C.orient or 1, C.bid)
        end
      end)
      C._syncing = nil
    end
    if not C.synced then
      error("Zy pipeline: call Zy.Screen.sync() first", 2)
    end
  end
  if stage == "touch" or stage == "verify" then
    C.require_design()
  end
end

return C
