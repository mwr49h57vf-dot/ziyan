--[[ 应用：经 SpringBoard IPC 打开/关闭（对齐「先开游再做事」习惯，自有实现） ]]
local M = {}

local function defined(n) return type(_G[n]) == "function" end

local ZS = (function()
  local ok, mod = pcall(require, "zy_shell")
  if ok and type(mod) == "table" and type(mod.run_capture) == "function" then return mod end
  local base = _G.ZIYAN_LUA or "/usr/lib/ziyan/lib/lua"
  for _, path in ipairs({
    base .. "/modules/zy_shell.lua",
    "/var/jb/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
    "/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
  }) do
    local f = io.open(path, "r")
    if f then
      f:close()
      local loaded, candidate = pcall(dofile, path)
      if loaded and type(candidate) == "table"
          and type(candidate.run_capture) == "function" then
        return candidate
      end
    end
  end
  return nil
end)()

local function var_dir()
  if type(_G.ZIYAN_VAR) == "string" and #_G.ZIYAN_VAR > 0 then
    return _G.ZIYAN_VAR
  end
  local f = io.open("/var/jb/usr/lib/ziyan/var", "r")
  if f then
    f:close()
    return "/var/jb/usr/lib/ziyan/var"
  end
  return "/usr/lib/ziyan/var"
end

local function write_ipc(name, body)
  local path = var_dir() .. "/" .. name
  local ok, reserved = pcall(os.tmpname)
  if not ok or type(reserved) ~= "string" or reserved == "" then return false end
  os.remove(reserved)
  local pending = path .. "." .. reserved:match("[^/]+$") .. ".tmp"
  local f = io.open(pending, "w")
  if not f then return false end
  local written = f:write(tostring(body or ""))
  local closed = f:close()
  if written and closed and os.rename(pending, path) then return true end
  os.remove(pending)
  return false
end

local function bundle_id(value)
  local bid = tostring(value or ""):match("^%s*(.-)%s*$")
  if not bid:match("^[A-Za-z][A-Za-z0-9%.%-]*$")
      or not bid:find("%.") or bid:find("%.%.") or bid:sub(-1) == "." then
    return nil
  end
  return bid
end

local function read_line(path)
  local f = io.open(path, "r")
  if not f then return "" end
  local s = f:read("*l") or ""
  f:close()
  return (s:gsub("%s+$", ""))
end

local function sleep_ms(ms)
  ms = tonumber(ms) or 0
  if ms <= 0 then return end
  if defined("mSleep") then
    mSleep(ms)
  else
    os.execute(string.format("sleep %.3f", ms / 1000))
  end
end

--- 当前前台 bundle（SpringBoard 写入 .ziyan_front_bid）
local function frontAppBid()
  return read_line(var_dir() .. "/.ziyan_front_bid")
end

local function frontApp()
  return frontAppBid()
end

--- 进程是否在跑：前台匹配或 ps 兜底
local function appRunning(bid)
  bid = bundle_id(bid)
  if not bid then return false end
  if frontAppBid() == bid then return true end
  local ok = false
  pcall(function()
    local line = ZS and ZS.run_capture(string.format(
      "ps aux 2>/dev/null | grep -F '%s' | grep -v grep | head -1", bid)) or ""
    ok = type(line) == "string" and #line > 0
  end)
  return ok
end

function M.install()
  if _G.__ZIYAN_APP_API_INSTALLED then return M end
  local nativeAppRun = defined("appRun") and appRun or nil
  local nativeAppKill = defined("appKill") and appKill or nil

  function appRun(bid)
    bid = bundle_id(bid)
    if not bid then return false end
    if frontAppBid() == bid then return true end
    if write_ipc(".ziyan_open_app", bid .. "\n") then
      if waitFrontApp(bid, 1000) then return true end
    end
    -- A submitted request is not a launch. Retire it before the system fallback
    -- so a delayed IPC consumer cannot reopen the app after this call returns.
    local pending = var_dir() .. "/.ziyan_open_app"
    if read_line(pending) == bid then os.remove(pending) end
    for _, tool in ipairs({"/var/jb/usr/bin/uiopen", "/usr/bin/uiopen"}) do
      local f = io.open(tool, "r")
      if f then
        f:close()
        local ok, result = pcall(os.execute, tool .. " --bundleid " .. bid)
        if ok and (result == true or result == 0) then
          return waitFrontApp(bid, 5000)
        end
        return frontAppBid() == bid
      end
    end
    if type(nativeAppRun) == "function" then
      local ok, r = pcall(nativeAppRun, bid)
      if ok and r then return waitFrontApp(bid, 5000) end
    end
    return false
  end

  function runApp(bid)
    return appRun(bid)
  end

  function openApp(bid)
    return appRun(bid)
  end

  function waitFrontApp(bid, timeoutMs)
    bid = bundle_id(bid)
    if not bid then return false end
    timeoutMs = math.max(0, tonumber(timeoutMs) or 8000)
    local mono = _G.ziyan_embed_monotonic_ms
    local deadline = type(mono) == "function" and mono() + timeoutMs or nil
    local left = timeoutMs
    while left > 0 do
      if frontAppBid() == bid then return true end
      if deadline then left = math.min(left, deadline - mono()) end
      if left <= 0 then break end
      local slice = math.min(200, left)
      sleep_ms(slice)
      -- shortcut: CLI fallback counts requested sleep; use the embedded monotonic clock for measured deadlines.
      left = left - slice
    end
    return frontAppBid() == bid
  end

  local function waitFrontAppGone(bid, timeoutMs)
    timeoutMs = math.max(0, tonumber(timeoutMs) or 2000)
    local mono = _G.ziyan_embed_monotonic_ms
    local deadline = nil
    if type(mono) == "function" then
      local ok, now = pcall(mono)
      if ok and type(now) == "number" then deadline = now + timeoutMs end
    end
    local left = timeoutMs
    while left > 0 and frontAppBid() == bid do
      local slice = math.min(100, left)
      sleep_ms(slice)
      if deadline then
        local ok, now = pcall(mono)
        if ok and type(now) == "number" then
          left = deadline - now
        else
          left = left - slice
        end
      else
        left = left - slice
      end
    end
    return frontAppBid() ~= bid
  end

  function appKill(bid)
    bid = bundle_id(bid)
    if not bid then return false end
    local was_front = frontAppBid() == bid
    if write_ipc(".ziyan_close_app", bid .. "\n") then
      sleep_ms(250)
      if not was_front then
        return true -- 后台目标只需确认请求已原子提交
      end
      -- 前台目标必须等待前台变化，避免 closeApp 返回 true 后业务立刻
      -- 读到旧画面并把“提交成功”误判为“关闭完成”。
      return waitFrontAppGone(bid, 2000)
    end
    if type(nativeAppKill) == "function" then
      local ok, result = pcall(nativeAppKill, bid)
      return ok and not not result
    end
    return false
  end

  function closeApp(bid, flag)
    return appKill(bid)
  end

  --- 开游 → 等前台 → 同步逻辑屏
  function runAppAndSync(bid, orient, waitMs)
    orient = tonumber(orient)
    if orient == nil then
      orient = tonumber(_G.__ZIYAN_ORIENT) or 1
    end
    waitMs = tonumber(waitMs) or 2000
    local ok = appRun(bid)
    if not ok then return false end
    if not waitFrontApp(bid, math.max(waitMs, 3000)) then return false end
    sleep_ms(waitMs)
    if type(syncGameScreen) == "function" then
      syncGameScreen(orient, bid)
    elseif type(init) == "function" then
      init(orient)
    end
    return ok
  end

  _G.__ZIYAN_NATIVE_APP_RUN = nativeAppRun
  _G.__ZIYAN_NATIVE_APP_KILL = nativeAppKill
  _G.frontAppBid = frontAppBid
  _G.frontApp = frontApp
  _G.appRunning = appRunning
  _G.__ZIYAN_APP_API_INSTALLED = true
  return M
end

return M
