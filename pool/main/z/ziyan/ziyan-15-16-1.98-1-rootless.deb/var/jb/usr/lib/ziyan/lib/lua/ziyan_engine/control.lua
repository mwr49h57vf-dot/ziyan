--[[ 控制：暂停 / 继续 / 停止（音量−菜单协同） ]]
local ZIYAN_VAR = _G.ZIYAN_VAR
if type(ZIYAN_VAR) ~= "string" or ZIYAN_VAR == "" then
  if io.open("/var/jb/usr/lib/ziyan/var", "r") then
    ZIYAN_VAR = "/var/jb/usr/lib/ziyan/var"
  else
    ZIYAN_VAR = "/usr/lib/ziyan/var"
  end
end
local PAUSE_FLAG = ZIYAN_VAR .. "/.ziyan_paused"
local STOP_FLAG = ZIYAN_VAR .. "/.ziyan_stop"

local M = {}
local thermal_observer
local pause_getinfo = debug and type(debug.getinfo) == "function" and debug.getinfo

local function exists(path)
  local f = io.open(path, "r")
  if f then f:close(); return true end
  return false
end

local function sleep_duration(ms)
  ms = tonumber(ms) or 0
  if ms ~= ms or ms == math.huge or ms == -math.huge then
    error("ziyan_sleep_nonfinite", 0)
  end
  return ms
end

local function checked_sleep(native, ms)
  -- 原生函数成功时无返回值；只有显式 false 表示失败。
  if native(ms) == false then error("ziyan_sleep_failed", 0) end
end

local function shell_sleep(ms)
  local bin = _G.ZIYAN_SLEEP or "sleep"
  local st = os.execute(string.format("'%s' %.3f", bin, ms / 1000.0))
  if st ~= true and st ~= 0 then error("ziyan_sleep_failed", 0) end
end

local function native_sleep(ms)
  ms = sleep_duration(ms)
  if ms <= 0 then
    return
  end
  -- 8-161-57：embed 优先 C usleep（禁 os.execute/busy-wait 拖死 framecap）
  if _G.ZIYAN_EMBED and type(_G.ziyan_embed_msleep) == "function" then
    checked_sleep(_G.ziyan_embed_msleep, ms)
    return
  end
  local n = _G.__ZIYAN_NATIVE_MSLEEP
  if type(n) == "function" then
    checked_sleep(n, ms)
    return
  end
  shell_sleep(ms)
end

-- 停止：绝不能 error()，否则触摸精灵/触动会弹「提示」堆栈窗
local function exit_on_stop()
  if not exists(STOP_FLAG) then return end
  pcall(os.remove, PAUSE_FLAG)
  -- 错误自动收集：强制停止是真实事件（幂等，一次停止只记一条）
  pcall(function()
    local er = _G.ErrorReporter
    if type(er) ~= "table" or type(er.on_stop) ~= "function" then return end
    local name = er.STOP_GUARD or ".ziyan_error_reporter_stop_done"
    local guard = ZIYAN_VAR .. "/" .. name
    local g = io.open(guard, "r")
    if g then g:close(); return end
    local w = io.open(guard, "w")
    if w then w:write(os.date("%Y-%m-%d %H:%M:%S") .. " stop\n"); w:close() end
    er.on_stop("user_stop", { phase = "control" })
  end)
  if type(scriptStop) == "function" then
    pcall(scriptStop)
  end
  -- embed 的 os.exit 透传同一 terminal token；standalone 仍由 Lua 直接退出。
  os.exit(0)
end

local function wait_while_paused(user_only)
  local waiting = false
  while true do
    exit_on_stop()
    local held = not user_only and thermal_observer
        and thermal_observer.thermal_tick()
    local paused = exists(PAUSE_FLAG)
    if not paused and not held then
      if waiting and thermal_observer and thermal_observer.wait_heartbeat then
        thermal_observer.wait_heartbeat("running")
      end
      return
    end
    waiting = true
    if thermal_observer and thermal_observer.wait_heartbeat then
      thermal_observer.wait_heartbeat(paused and "user_pause" or "thermal")
    end
    if held then
      local sleep = _G.ziyan_embed_msleep
      if type(sleep) ~= "function" then
        error("ziyan_thermal_sleep_unavailable", 0)
      end
      checked_sleep(sleep, 50)
    else
      native_sleep(50)
    end
  end
end

local function shared_pause_point()
  -- touch.lua 也调用旧用户暂停回调；热保护不得进入该触控路由。
  local caller = pause_getinfo and pause_getinfo(2, "S")
  -- 无 caller 时由 observer 已保留的完整栈检查判定，避免 reinstall 绕过 hold。
  local user_only = caller and caller.source:match("/ziyan_engine/touch%.lua$")
  return wait_while_paused(user_only)
end

function ziyan_pause_point()
  wait_while_paused()
end

function M.install(engine)
  thermal_observer = type(engine) == "table" and engine._thermal_observer or nil
  if type(thermal_observer) ~= "table" or type(thermal_observer.thermal_tick) ~= "function" then
    thermal_observer = nil
  end
  if _G.ZIYAN_EMBED and type(_G.ziyan_embed_msleep) == "function" then
    _G.__ZIYAN_NATIVE_MSLEEP = _G.ziyan_embed_msleep
  end
  -- 无原生 mSleep（纯 lua5.3）时提供 shell sleep 兜底，再包装暂停检查点
  if type(mSleep) ~= "function" and not _G.__ZIYAN_NATIVE_MSLEEP then
    mSleep = shell_sleep
  end
  if type(mSleep) == "function" and not _G.__ZIYAN_NATIVE_MSLEEP then
    _G.__ZIYAN_NATIVE_MSLEEP = mSleep
  end
  local native = _G.__ZIYAN_NATIVE_MSLEEP
  if type(native) ~= "function" then
    _G.__ZIYAN_wait_while_paused = shared_pause_point
    return M
  end
  local _last_session_pulse = 0
  function mSleep(ms)
    ms = sleep_duration(ms)
    wait_while_paused()
    -- ★ HealthMonitor 注入：每轮 mSleep 自动触发健康检查（9 维度）
    -- 8-161-61：light 热路径禁 pulse（假阳性降频会把循环拖到数十秒）
    if ms > 0 and _G.HealthMonitor and not _G.__ZIYAN_SAFE_MSLEEP_ACTIVE
        and not _G.ZIYAN_LIGHT then
      pcall(_G.HealthMonitor.pulse)
    end
    if ms <= 0 then
      wait_while_paused()
      exit_on_stop()
      return
    end
    -- 2026-09-16 修正 mSleep 累积超时（实测请求 1000ms 实耗 2329~2596ms）。
    --
    -- 旧实现：`local chunk = 150; native(chunk); left = left - chunk`
    --   —— 无论 native(150) 实际花了多久都只减 150。而设备全是 ncpu=2 且
    --   load average 1.97~5.80（超核数），单片实测唤醒延迟 60~116ms，
    --   1000ms 被拆成 7 片就把延迟积成 2.3 倍。这正是用户报的
    --   「脚本节奏比写的慢」。
    --
    -- 改为**绝对截止时间**驱动：以单调时钟为准，每片只问「还剩多少」。
    -- 睡过头立即结束，不再累积。分片仅保留 stop/pause 的可打断性。
    local mono = _G.ziyan_embed_monotonic_ms
    local deadline, last_mono = nil, nil
    if type(mono) == "function" then
      local ok0, t0 = pcall(mono)
      if ok0 and type(t0) == "number" and t0 >= 0 and t0 < math.huge then
        deadline = t0 + ms
        if deadline < t0 or deadline == math.huge then
          error("ziyan_sleep_clock_or_overflow", 0)
        end
        last_mono = t0
      end
    end
    local left = ms
    while left > 0 do
      wait_while_paused()
      exit_on_stop()
      -- R8.1：每 20s 续写会话文件 + 触发 unlock（SB 重启后自动恢复）
      local now = os.time() or 0
      if (now - _last_session_pulse) >= 20 then
        _last_session_pulse = now
        if type(_G.__ZIYAN_mark_session) == "function" then
          pcall(_G.__ZIYAN_mark_session)
        end
      end
      local tnow
      if deadline then
        local ok1
        ok1, tnow = pcall(mono)
        if ok1 and type(tnow) == "number" and tnow >= last_mono
            and tnow < math.huge then
          left = deadline - tnow
          if left <= 0 then break end
        else
          deadline = nil
        end
      end
      local chunk = left > 200 and 200 or left
      if left - chunk == left then error("ziyan_sleep_clock_or_overflow", 0) end
      checked_sleep(native, chunk)
      if deadline then
        local ok2, t2 = pcall(mono)
        if ok2 and type(t2) == "number" and t2 > tnow and t2 < math.huge then
          left = deadline - t2
          last_mono = t2
        else
          -- 时钟失效后本次不再信任截止时间，避免冻结/倒退导致无限休眠。
          deadline = nil
          left = left - chunk
        end
      else
        left = left - chunk
      end
      exit_on_stop()
    end
    wait_while_paused()
  end
  _G.__ZIYAN_MSLEEP_WRAPPED = true
  _G.__ZIYAN_wait_while_paused = shared_pause_point
  return M
end

return M
