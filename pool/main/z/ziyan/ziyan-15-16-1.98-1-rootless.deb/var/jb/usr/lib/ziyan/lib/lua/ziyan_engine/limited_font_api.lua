-- ZiYan-owned v1 ASCII dictionary API; no TS compatibility globals installed.
local matcher = require("ziyan_engine.limited_font_find")
local M = {}

local CAPS = {
  max_fonts = 16, max_font_dimensions = 64, max_font_pixels = 262144,
  max_image_dimensions = 4096, max_pixels = 262144, max_text = 64,
  max_tolerance = 64, max_comparisons = 8000000,
}
local MAX_COORD = 16777215

local function finite(n)
  return type(n) == "number" and n == n and math.abs(n) < math.huge
end

local function integer(n)
  return finite(n) and n >= 0 and n <= 9007199254740991
      and n == math.floor(n)
end

local function token_copy(t)
  if type(t) ~= "table" or not integer(t.generation) or not integer(t.seq)
      or type(t.front_hash) ~= "string" or #t.front_hash < 1
      or #t.front_hash > 128 then
    return nil
  end
  return {generation = t.generation, front_hash = t.front_hash, seq = t.seq}
end

-- Own the binary pixels too: a provider may reuse its buffers after capture.
local function image_copy(image, roi, limits)
  if type(image) ~= "table" or not integer(image.width)
      or not integer(image.height) or image.width < 1 or image.height < 1
      or image.width > limits.max_image_dimensions
      or image.height > limits.max_image_dimensions then
    return false, "invalid_image_dimensions"
  end
  local width, height = image.width, image.height
  if width * height > limits.max_pixels then return false, "pixel_budget" end
  local ox, oy, scale = image.origin_x, image.origin_y, image.scale
  if not finite(ox) or not finite(oy) or not finite(scale)
      or scale < 1/16 or scale > 16 then
    return false, "invalid_mapping"
  end
  if ox < roi.x or oy < roi.y or ox + (width - 1) * scale > roi.x1
      or oy + (height - 1) * scale > roi.y1 then
    return false, "roi_mapping"
  end
  local rows, flat = image.pixels, image.data
  if rows ~= nil then
    if flat ~= nil or type(rows) ~= "table" or #rows ~= height then
      return false, "invalid_image_data"
    end
  elseif type(flat) ~= "table" or #flat ~= width * height then
    return false, "invalid_image_data"
  end
  local data = {}
  for y = 1, height do
    if rows and (type(rows[y]) ~= "table" or #rows[y] ~= width) then
      return false, "invalid_image_data"
    end
    for x = 1, width do
      local offset = (y - 1) * width + x
      local value
      if rows then value = rows[y][x] else value = flat[offset] end
      if value == 1 or value == true or value == "1" then
        data[offset] = 1
      elseif value == 0 or value == false or value == "0" then
        data[offset] = 0
      else
        return false, "non_binary_image"
      end
    end
  end
  return {width = width, height = height, data = data,
          origin_x = ox, origin_y = oy, scale = scale}
end

function M.new(options)
  if type(options) ~= "table" or type(options.snapshotProvider) ~= "function" then
    return false, "snapshot_provider_required"
  end
  local snapshot = options.snapshotProvider
  local validate, current = options.validate, options.validateProvider
  if (validate ~= nil and current ~= nil)
      or (validate == nil and type(current) ~= "function")
      or (validate ~= nil and type(validate) ~= "function") then
    return false, "exactly_one_validator_required"
  end
  local limits, overrides = {}, options.limits or {}
  if type(overrides) ~= "table" then return false, "invalid_limits" end
  for key in pairs(overrides) do
    if not CAPS[key] then return false, "unknown_limit" end
  end
  for key, cap in pairs(CAPS) do
    local value = overrides[key]
    if value == nil then value = cap end
    if not integer(value) or value < 1 or value > cap then
      return false, "invalid_limits"
    end
    limits[key] = value
  end
  local fonts, instance, font_count = {}, {}, 0

  function instance:register(id, font)
    if type(id) ~= "string" or #id < 1 or #id > 64 then
      return false, "invalid_dictionary_id"
    end
    if not fonts[id] and font_count >= limits.max_fonts then
      return false, "font_budget"
    end
    if type(font) ~= "table" or not integer(font.width) or not integer(font.height)
        or font.width < 1 or font.height < 1
        or font.width > limits.max_font_dimensions
        or font.height > limits.max_font_dimensions then
      return false, "invalid_font_dimensions"
    end
    if type(font.glyphs) ~= "table" then return false, "invalid_font" end
    local copy, count = {version = font.version, width = font.width,
                       height = font.height, glyphs = {}}, 0
    for key, rows in pairs(font.glyphs) do
      count = count + 1
      if count > 95 or count * font.width * font.height > limits.max_font_pixels then
        return false, "font_pixel_budget"
      end
      if type(rows) ~= "table" or #rows ~= font.height then
        return false, "invalid_font"
      end
      local glyph = {}
      for row = 1, font.height do glyph[row] = rows[row] end
      copy.glyphs[key] = glyph
    end
    local engine = matcher.new(copy)
    if not engine then return false, "invalid_font" end
    if not fonts[id] then font_count = font_count + 1 end
    fonts[id] = engine
    return true
  end

  function instance:find(id, text, roi, tolerance)
    local font = fonts[id]
    if not font then return false, "unknown_dictionary" end
    if type(text) ~= "string" or #text < 1 or #text > limits.max_text
        or text:find("[^ -~]") then
      return false, "invalid_text"
    end
    for index = 1, #text do
      if not font.glyphs[text:sub(index, index)] then
        return false, "unknown_glyph"
      end
    end
    if type(roi) ~= "table" or not integer(roi.x) or not integer(roi.y)
        or not integer(roi.x1) or not integer(roi.y1)
        or roi.x1 < roi.x or roi.y1 < roi.y
        or roi.x1 > MAX_COORD or roi.y1 > MAX_COORD
        or roi.x1 - roi.x > 8191 or roi.y1 - roi.y > 8191 then
      return false, "invalid_roi"
    end
    if tolerance == nil then tolerance = 0 end
    if not integer(tolerance) or tolerance > limits.max_tolerance
        or tolerance > font.width * font.height then
      return false, "invalid_tolerance"
    end
    -- Preserve the caller's ROI even if a provider mutates its request table.
    local bounds = {x = roi.x, y = roi.y, x1 = roi.x1, y1 = roi.y1}
    local request = {x = bounds.x, y = bounds.y, x1 = bounds.x1, y1 = bounds.y1}
    local budget = {max_pixels = limits.max_pixels,
                    max_image_dimensions = limits.max_image_dimensions}
    local ok, image, raw_token = pcall(snapshot, request, budget)
    if not ok then return false, "snapshot_failed" end
    if image == nil or image == false then return false, "snapshot_unavailable" end
    local token = token_copy(raw_token)
    if not token then return false, "invalid_token" end
    local owned, err = image_copy(image, bounds, limits)
    if not owned then return false, err end
    -- ponytail: exhaustive search, bounded by worst-case pixel comparisons;
    -- replace the core only if measured throughput needs a faster matcher.
    local positions = math.max(0, owned.width - font.width * #text + 1)
        * math.max(0, owned.height - font.height + 1)
    if positions * #text * font.width * font.height > limits.max_comparisons then
      return false, "comparison_budget"
    end
    local x, y = font:find(owned, text, nil, nil, nil, nil, tolerance)
    if x == false then return false, y end
    -- Compute from owned metadata before invoking the final validation callback.
    if x ~= -1 then
      x, y = owned.origin_x + (x - 1) * owned.scale,
             owned.origin_y + (y - 1) * owned.scale
    end
    local checked, valid
    if validate then
      -- Only literal true certifies that the snapshot token is still valid.
      checked, valid = pcall(validate, token_copy(token))
    else
      local result
      checked, result = pcall(current)
      local latest = token_copy(result)
      valid = latest and latest.generation == token.generation
          and latest.front_hash == token.front_hash and latest.seq == token.seq
    end
    if not checked then return false, "validation_failed" end
    if valid ~= true then return false, "stale_frame" end
    return x, y, token
  end

  return instance
end

return M
