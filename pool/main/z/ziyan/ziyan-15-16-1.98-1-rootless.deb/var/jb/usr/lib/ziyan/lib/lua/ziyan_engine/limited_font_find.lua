-- ZiYan-owned finite font matcher.
-- This is deliberately separate from the TouchSprite compatibility registry.

local M = {}

local function fail(message)
  return false, message
end

local function is_integer(value)
  return type(value) == "number" and value == math.floor(value)
end

local function validate_glyph(glyph, width, height, label)
  if type(glyph) ~= "table" or #glyph ~= height then
    return nil, label .. ": expected " .. height .. " rows"
  end
  for row = 1, height do
    if type(glyph[row]) ~= "string" or #glyph[row] ~= width
        or glyph[row]:find("[^01]") then
      return nil, label .. ": row " .. row .. " must contain " .. width
        .. " binary characters"
    end
  end
  return glyph
end

function M.validate_font(font)
  if type(font) ~= "table" then
    return fail("font must be a table")
  end
  if font.version ~= 1 then
    return fail("font.version must be 1")
  end
  if not is_integer(font.width) or font.width < 1
      or not is_integer(font.height) or font.height < 1 then
    return fail("font.width and font.height must be positive integers")
  end
  if type(font.glyphs) ~= "table" then
    return fail("font.glyphs must be a table")
  end
  local count = 0
  for key, glyph in pairs(font.glyphs) do
    if type(key) ~= "string" or #key ~= 1 then
      return fail("glyph keys must be single-byte ASCII characters")
    end
    if string.byte(key) < 32 or string.byte(key) > 126 then
      return fail("glyph keys must be printable ASCII")
    end
    local ok, err = validate_glyph(glyph, font.width, font.height, "glyph " .. key)
    if not ok then
      return fail(err)
    end
    count = count + 1
  end
  if count == 0 then
    return fail("font.glyphs must not be empty")
  end
  return true
end

function M.new(font)
  local ok, err = M.validate_font(font)
  if not ok then
    return false, err
  end
  return setmetatable({
    width = font.width,
    height = font.height,
    glyphs = font.glyphs,
  }, {__index = M})
end

local function pixel(image, x, y)
  if image.pixels then
    return image.pixels[y][x]
  end
  return image.data[(y - 1) * image.width + x]
end

local function validate_image(image)
  if type(image) ~= "table" or not is_integer(image.width)
      or not is_integer(image.height) or image.width < 1 or image.height < 1 then
    return false, "image.width and image.height must be positive integers"
  end
  if image.pixels then
    if type(image.pixels) ~= "table" or #image.pixels ~= image.height then
      return false, "image.pixels must have one row per image height"
    end
    for y = 1, image.height do
      if type(image.pixels[y]) ~= "table" or #image.pixels[y] ~= image.width then
        return false, "image.pixels rows must match image.width"
      end
    end
  elseif type(image.data) == "table" and #image.data == image.width * image.height then
    -- accepted
  else
    return false, "image requires pixels or flat data"
  end
  return true
end

local function bit(value)
  if value == true or value == 1 or value == "1" then
    return 1
  end
  return 0
end

local function matches(image, glyph, left, top, tolerance)
  local errors = 0
  for row = 1, #glyph do
    local pattern = glyph[row]
    for col = 1, #pattern do
      if bit(pixel(image, left + col - 1, top + row - 1))
          ~= (pattern:sub(col, col) == "1" and 1 or 0) then
        errors = errors + 1
        if errors > tolerance then
          return false
        end
      end
    end
  end
  return true
end

-- Returns x,y on the first row-major match; -1,-1 on a valid miss.
function M:find(image, text, x, y, x1, y1, tolerance)
  local ok, err = validate_image(image)
  if not ok then
    return false, err
  end
  if type(text) ~= "string" or text == "" or text:find("[^ -~]") then
    return false, "text must be non-empty printable ASCII"
  end
  x, y = x or 1, y or 1
  x1, y1 = x1 or image.width, y1 or image.height
  tolerance = tolerance or 0
  if not is_integer(x) or not is_integer(y) or not is_integer(x1)
      or not is_integer(y1) or x < 1 or y < 1 or x1 > image.width
      or y1 > image.height or x > x1 or y > y1 then
    return false, "ROI is outside image"
  end
  if not is_integer(tolerance) or tolerance < 0
      or tolerance > self.width * self.height * #text then
    return false, "tolerance is out of range"
  end
  for index = 1, #text do
    if not self.glyphs[text:sub(index, index)] then
      return false, "text contains glyph not present in font"
    end
  end
  local cursor_width = self.width * #text
  if cursor_width > x1 - x + 1 or self.height > y1 - y + 1 then
    return -1, -1
  end
  for top = y, y1 - self.height + 1 do
    for left = x, x1 - cursor_width + 1 do
      local matched = true
      for index = 1, #text do
        local glyph = self.glyphs[text:sub(index, index)]
        if not matches(image, glyph, left + (index - 1) * self.width, top,
                       tolerance) then
          matched = false
          break
        end
      end
      if matched then
        return left, top
      end
    end
  end
  return -1, -1
end

return M
