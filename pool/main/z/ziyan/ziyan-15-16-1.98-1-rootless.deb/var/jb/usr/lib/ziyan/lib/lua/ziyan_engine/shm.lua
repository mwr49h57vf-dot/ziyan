--[[
  8-154：ControlShm 双写桥（ziyanctl）
  - 热路径默认开启（存在 .ziyan_control_shm 或可写 var）
  - 写 .ziyan_shm_disabled 可关；写 .ziyan_shm_lua_off 可关热双写
  - 禁止阻塞：失败静默回退文件 IPC
]]

local M = {}

local ZS = (function()
  local ok, mod = pcall(require, "zy_shell")
  if ok and type(mod) == "table" and type(mod.run_capture_status) == "function" then return mod end
  local base = _G.ZIYAN_LUA or "/usr/lib/ziyan/lib/lua"
  for _, path in ipairs({
    base .. "/modules/zy_shell.lua",
    "/var/jb/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
    "/usr/lib/ziyan/lib/lua/modules/zy_shell.lua",
  }) do
    local f = io.open(path, "r")
    if f then
      f:close()
      local loaded, candidate = pcall(dofile, path)
      if loaded and type(candidate) == "table"
          and type(candidate.run_capture_status) == "function" then
        return candidate
      end
    end
  end
  return nil
end)()

local function resolve_var()
  if type(_G.ZIYAN_VAR) == "string" and #_G.ZIYAN_VAR > 0 then
    return _G.ZIYAN_VAR
  end
  local f = io.open("/var/jb/usr/lib/ziyan/var", "r")
  if f then
    f:close()
    return "/var/jb/usr/lib/ziyan/var"
  end
  return "/usr/lib/ziyan/var"
end

local function resolve_ctl()
  local cands = {
    "/var/jb/usr/lib/ziyan/bin/ziyanctl",
    "/usr/lib/ziyan/bin/ziyanctl",
  }
  for i = 1, #cands do
    local f = io.open(cands[i], "r")
    if f then
      f:close()
      return cands[i]
    end
  end
  return nil
end

local function shm_ok()
  local var = resolve_var()
  local f = io.open(var .. "/.ziyan_shm_disabled", "r")
  if f then
    f:close()
    return false
  end
  return resolve_ctl() ~= nil
end

--- 找色/触控热路径：默认开；.ziyan_shm_lua_off 可关；兼容旧 .ziyan_shm_lua 强制开
local function shm_hot_ok()
  if not shm_ok() then
    return false
  end
  if _G.__ZIYAN_SHM_LUA == false then
    return false
  end
  local var = resolve_var()
  local f = io.open(var .. "/.ziyan_shm_lua_off", "r")
  if f then
    f:close()
    return false
  end
  if _G.__ZIYAN_SHM_LUA == true then
    return true
  end
  -- 默认 ON（T2 验收：热路径走 shm 双写）
  return true
end

--- 转义单引号供 shell
local function q(s)
  return "'" .. tostring(s or ""):gsub("'", "'\\''") .. "'"
end

local function execute_ok(cmd)
  local ok, a, b, c = pcall(os.execute, cmd)
  if not ok then
    return false
  end
  if a == true then
    return true
  end
  return (a == "exit" and c == 0) or (type(a) == "number" and a == 0)
end

function M.available()
  return shm_ok()
end

--- 读控制标志：优先 mmap 文件 flags（offset=16），失败回退 .ziyan_paused/.ziyan_stop
function M.read_control_flags_fast()
  local var = resolve_var()
  local flags = { paused = false, stopped = false }
  local f = io.open(var .. "/.ziyan_control_shm", "rb")
  if f then
    local b = f:read(4097)
    f:close()
    -- Native v2: exactly 4096 bytes, magic 0x5A590001, flags at offset 16.
    if type(b) == "string" and #b == 4096
        and b:sub(1, 8) == string.char(1, 0, 89, 90, 2, 0, 0, 0) then
      local v = b:byte(17) + b:byte(18) * 256 + b:byte(19) * 65536 + b:byte(20) * 16777216
      -- STOP=bit1(2), PAUSED=bit2(4)
      flags.stopped = (math.floor(v / 2) % 2) == 1
      flags.paused = (math.floor(v / 4) % 2) == 1
      return flags
    end
  end
  -- fallback 文件 IPC
  local pf = io.open(var .. "/.ziyan_paused", "r")
  if pf then pf:close(); flags.paused = true end
  local sf = io.open(var .. "/.ziyan_stop", "r")
  if sf then sf:close(); flags.stopped = true end
  return flags
end

function M.read_control_flags()
  if not shm_ok() then
    return M.read_control_flags_fast()
  end
  local ctl = resolve_ctl()
  if not ZS then return M.read_control_flags_fast() end
  local out, code = ZS.run_capture_status(ctl .. " shm read_control_flags 2>/dev/null")
  if code ~= 0 then return M.read_control_flags_fast() end
  local paused = tonumber(out:match("paused=(%d)")) == 1
  local stopped = tonumber(out:match("stopped=(%d)")) == 1
  if out:find("paused=") then
    return { paused = paused, stopped = stopped }
  end
  return M.read_control_flags_fast()
end

--- 写控制标志：走 ziyanctl；失败不使用未经验证的 Lua 路径写入
function M.write_control_flags(paused, stopped)
  local ctl = resolve_ctl()
  local p = paused and 1 or 0
  local s = stopped and 1 or 0
  if shm_ok() then
    local cmd = string.format(
      "%s shm write_control_flags %d %d >/dev/null 2>&1",
      ctl, p, s
    )
    if execute_ok(cmd) then
      return true
    end
  end
  -- Lua 文件 API 不提供目录 FD/NOFOLLOW/原子提交，失败必须显式交给调用方。
  return false
end

function M.write_color(main, points_json, fuzzy, x1, y1, x2, y2, nonce)
  if not shm_hot_ok() then
    return false
  end
  local ctl = resolve_ctl()
  -- 同步写（mmap <5ms）；禁止 &，避免文件先被消费后再落 shm 造成双次找色
  local cmd = string.format(
    "%s shm write_color %s %s %s %s %s %s %s %s >/dev/null 2>&1",
    ctl,
    tostring(tonumber(main) or 0),
    tostring(tonumber(fuzzy) or 90),
    tostring(tonumber(x1) or 0),
    tostring(tonumber(y1) or 0),
    tostring(tonumber(x2) or -1),
    tostring(tonumber(y2) or -1),
    tostring(tonumber(nonce) or 0),
    q(points_json)
  )
  return execute_ok(cmd)
end

function M.write_touch(typ, x, y, hold_ms, finger, nonce)
  if not shm_hot_ok() then
    return false
  end
  local ctl = resolve_ctl()
  local cmd = string.format(
    "%s shm write_touch %d %d %d %d %d %s >/dev/null 2>&1",
    ctl,
    tonumber(typ) or 1,
    math.floor(tonumber(x) or 0),
    math.floor(tonumber(y) or 0),
    tonumber(hold_ms) or 90,
    tonumber(finger) or 1,
    tostring(tonumber(nonce) or 0)
  )
  return execute_ok(cmd)
end

function M.write_toast(text, ms)
  if not shm_ok() then
    return false
  end
  local ctl = resolve_ctl()
  if not ctl then
    return false
  end
  text = tostring(text or "")
  ms = tonumber(ms) or 1500
  -- 8-161-96：中文等非 ASCII 禁止塞进 shell argv（会变成 ÁôªÂΩï 一类 MacRoman 乱码）
  -- 改写 UTF-8 临时文件 → write_toast_file
  local var = resolve_var()
  local payload = var .. "/.ziyan_toast_shm_payload"
  local f = io.open(payload, "wb")
  if not f then
    return false
  end
  f:write(text)
  f:close()
  local cmd = string.format(
    "%s shm write_toast_file %d %s >/dev/null 2>&1",
    ctl,
    ms,
    q(payload)
  )
  local ok = execute_ok(cmd)
  pcall(os.remove, payload)
  return ok
end

function M.heartbeat(name)
  if not shm_ok() then
    return false
  end
  local ctl = resolve_ctl()
  return execute_ok(string.format(
    "%s shm heartbeat %s >/dev/null 2>&1",
    ctl,
    q(name or "lua")
  ))
end

_G.__ZIYAN_SHM_AVAILABLE = M.available()
_G.ZiYanShm = M

return M
