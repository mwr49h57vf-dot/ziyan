--[[ 触控：按触动精灵语义直接作用于当前前台屏幕。 ]]
local M = {}

-- rootless=/var/jb/usr/lib/ziyan/var ；rootful=/usr/lib/ziyan/var（勿写死 rootful）
local ZIYAN_VAR = _G.ZIYAN_VAR
if type(ZIYAN_VAR) ~= "string" or ZIYAN_VAR == "" then
  if io.open("/var/jb/usr/lib/ziyan/var", "r") then
    ZIYAN_VAR = "/var/jb/usr/lib/ziyan/var"
  else
    ZIYAN_VAR = "/usr/lib/ziyan/var"
  end
end
local TOUCH_REQ = ZIYAN_VAR .. "/.ziyan_touch_req"
local TOUCH_REP = ZIYAN_VAR .. "/.ziyan_touch_rep"
local TOUCH_REQ_MEDIA = "/private/var/mobile/Media/ZiYan/.ziyan_touch_req"

local function defined(n) return type(_G[n]) == "function" end

local function checkpoint()
  if type(_G.__ZIYAN_wait_while_paused) == "function" then
    _G.__ZIYAN_wait_while_paused()
  end
end

-- 每指最后一次 down 的逻辑坐标（touchUp(finger) 无坐标时用，避免抬在 0,0）
local _last_down = {}

local _nonce = 0
local function next_nonce()
  _nonce = _nonce + 1
  return tostring(os.time()) .. "_" .. tostring(_nonce)
end

local function wait_touch_rep(nonce, timeout_s)
  -- embed 用单调墙钟；冷路径再用有界轮询。禁止 os.clock（CPU 时间）把 1.5s
  -- 等待放大成几十秒。
  timeout_s = tonumber(timeout_s) or 0.8
  local native_clock = type(_G.ziyan_embed_monotonic_ms) == "function"
  local deadline_ms = nil
  if native_clock then
    local ok, now = pcall(_G.ziyan_embed_monotonic_ms)
    if ok and tonumber(now) then
      deadline_ms = tonumber(now) + timeout_s * 1000
    end
  end
  local poll_ms = 2
  local max_spins = math.max(1, math.ceil(timeout_s * 1000 / poll_ms))
  local spins = 0
  while spins < max_spins do
    spins = spins + 1
    local r = io.open(TOUCH_REP, "r")
    if r then
      local n = r:read("*l")
      local st = r:read("*l")
      r:close()
      if n == nonce then
        pcall(os.remove, TOUCH_REP)
        return st == "ok"
      end
    end
    if deadline_ms then
      local ok, now = pcall(_G.ziyan_embed_monotonic_ms)
      if ok and tonumber(now) and tonumber(now) >= deadline_ms then
        break
      end
    end
    if type(_G.__ZIYAN_RAW_MSLEEP) == "function" then
      pcall(_G.__ZIYAN_RAW_MSLEEP, poll_ms)
    elseif type(mSleep) == "function" then
      pcall(mSleep, poll_ms)
    end
    if spins % 10 == 0 and type(_G.__ZIYAN_RAW_MSLEEP) ~= "function"
        and type(mSleep) ~= "function" then
      pcall(os.execute, "sleep 0.002")
    end
  end
  return nil -- 超时无回执
end

local function write_touch_req(body)
  -- 原子写：避免 open("w") 截断空窗被 SB/AppTouch 误删
  local function atomic_write(path, payload)
    local tmp = path .. ".tmp." .. tostring(math.floor((os.clock() or 0) * 1e6) % 1e8)
    local f = io.open(tmp, "w")
    if not f then return false end
    f:write(payload)
    f:close()
    pcall(os.remove, path)
    if os.rename(tmp, path) then
      return true
    end
    f = io.open(path, "w")
    if not f then
      pcall(os.remove, tmp)
      return false
    end
    f:write(payload)
    f:close()
    pcall(os.remove, tmp)
    return true
  end
  local ok = atomic_write(TOUCH_REQ, body)
  -- 镜像到 Media（瞬时 IPC，消费后删除；非脚本/配置落盘）
  pcall(atomic_write, TOUCH_REQ_MEDIA, body)
  return ok
end

--- 逻辑坐标 → 触控桥（与 findMultiColor 同一 init(0/1/2)；Oc 侧 OrientMap，勿先 to_phys）
--- strict=true：超时/无回执一律失败（抬起必须严格，禁止假成功导致粘指）
local function hid_phase(phase, id, x, y, strict)
  x, y = tonumber(x) or 0, tonumber(y) or 0
  id = tonumber(id) or 1
  if phase == "down" then
    _last_down[id] = { x = x, y = y }
  end
  -- embed 的唯一原生触控入口优先于文件 IPC；它直接把事件交给当前前台
  -- 屏幕，不读取 Bundle、frontApp 或 AppTouch 偏好。
  if defined("ziyan_embed_touch_phase") then
    local ok = ziyan_embed_touch_phase(phase, id, x, y)
    if ok == true then
      if phase == "up" then _last_down[id] = nil end
      return true
    end
    -- 原生 embed 只在当前宿主具备 HID 路由时可用；失败必须回落到
    -- SpringBoard 当前前台桥，不能把“无原生路由”直接暴露成业务失败。
  end
  local nonce = next_nonce()
  pcall(os.remove, TOUCH_REP)
  local body = table.concat({
    "touch", tostring(phase), tostring(id), tostring(x), tostring(y), nonce, ""
  }, "\n")
  if not write_touch_req(body) then return false end
  local timeout = (phase == "up") and 0.8 or 0.5
  local ok = wait_touch_rep(nonce, timeout)
  if ok == true then
    if phase == "up" then
      _last_down[id] = nil
    end
    return true
  end
  if ok == false then return false end
  -- 无真实回执即失败，避免把未完成的触控报告成成功。
  return false
end

function M.install()
  local function parse_args(a, b, c)
    if c == nil and b ~= nil then
      -- touchDown(x,y)：默认单指，逻辑坐标原样
      return 1, a, b
    end
    local id = tonumber(a) or 1
    if id < 1 or id > 9 then
      id = 1
    end
    return id, b, c
  end

  function touchDown(a, b, c)
    checkpoint()
    local id, x, y = parse_args(a, b, c)
    if hid_phase("down", id, x, y) then
      _last_down[id] = { x = x, y = y }
      return true
    end
    return false
  end

  function touchMove(a, b, c)
    checkpoint()
    local id, x, y = parse_args(a, b, c)
    if hid_phase("move", id, x, y) then
      return true
    end
    return false
  end

  function touchUp(a, b, c)
    checkpoint()
    local id, x, y
    if b == nil then
      id = tonumber(a) or 1
      local last = _last_down[id]
      x = last and last.x or 0
      y = last and last.y or 0
      local ok = false
      for _ = 1, 3 do
        if hid_phase("up", id, x, y, true) then
          ok = true
          break
        end
        if type(mSleep) == "function" then mSleep(30) end
      end
      return ok
    end
    id, x, y = parse_args(a, b, c)
    local ok = false
    for _ = 1, 3 do
      if hid_phase("up", id, x, y, true) then
        ok = true
        break
      end
      if type(mSleep) == "function" then mSleep(30) end
    end
    if ok then return true end
    return false
  end

  --- 解析 tap 参数
  ---   tap(x, y [, holdMs])
  ---   tap(finger, x, y [, holdMs])  finger: 1..9
  local function parse_tap_args(a, b, c, d)
    a, b, c, d = tonumber(a), tonumber(b), tonumber(c), tonumber(d)
    if a == nil or b == nil then
      return nil
    end
    if c ~= nil and d ~= nil then
      return a, b, c, d -- finger, x, y, holdMs
    end
    if c ~= nil then
      -- tap(x, y, holdMs)：前三个参数固定按坐标、时长解释。
      -- 不再根据数值大小猜测 finger，避免固定整数坐标被改写。
      return nil, a, b, c
    end
    return nil, a, b, nil -- tap(x, y)
  end

  --- 原子 tap：始终作用于当前前台，按固定回退链投递。
  --- 不按当前 Bundle、桌面或嵌入宿主做业务分流。
  local function hid_tap(id, x, y, holdMs)
    x, y = tonumber(x) or 0, tonumber(y) or 0
    id = math.max(1, math.min(9, math.floor(tonumber(id) or 1)))
    holdMs = math.floor(tonumber(holdMs) or 90)
    if holdMs < 0 or holdMs > 5000 then return false end

    -- 统一走 SpringBoard 当前前台桥。embed 侧直接 HID 的 ok 只代表事件
    -- 被系统接口接受，不能证明前台 UI 已消费；不能因此截断当前屏幕投递。
    local nonce = next_nonce()
    pcall(os.remove, TOUCH_REP)
    local body = table.concat({
      "tap", tostring(id), tostring(x), tostring(y),
      tostring(holdMs), nonce, ""
    }, "\n")
    if not write_touch_req(body) then return false end
    -- ACK 在抬手后才写；两种模式均保留完整 hold 和原有投递预算。
    local ok = wait_touch_rep(nonce, holdMs / 1000 + 1.5)
    pcall(os.remove, TOUCH_REQ)
    pcall(os.remove, TOUCH_REQ_MEDIA)
    return ok == true
  end

  --- tap(x, y [, holdMs]) / tap(finger, x, y [, holdMs])
  --- 传入什么坐标就按什么坐标；找色/找图/找字坐标与固定整数共用此入口。
  function tap(a, b, c, d)
    checkpoint()
    local finger, x, y, holdMs = parse_tap_args(a, b, c, d)
    if x == nil or y == nil then
      return false
    end
    -- 未提供扩展参数时使用固定单指短按；不改业务坐标或时长参数。
    finger = finger or 1
    holdMs = tonumber(holdMs) or 90

    return hid_tap(finger, x, y, holdMs)
  end

  if not defined("moveTo") then
    function moveTo(x1, y1, x2, y2, step, ms)
      step = step or 10
      ms = ms or 50
      if not touchDown(1, x1, y1) then
        touchUp(1, x1, y1)
        return false
      end
      if defined("mSleep") then mSleep(20) end
      local dx, dy = x2 - x1, y2 - y1
      local n = math.max(1, math.floor(math.max(math.abs(dx), math.abs(dy)) / math.max(step, 1)))
      for i = 1, n do
        local x, y = x1 + dx * i / n, y1 + dy * i / n
        if not touchMove(1, x, y) then
          touchUp(1, x, y)
          return false
        end
        if defined("mSleep") then
          mSleep(math.max(1, math.floor(ms / n)))
        end
      end
      return touchUp(1, x2, y2)
    end
  end

  --- 滑动：逻辑坐标（与 tap 同一套）
  function swipe(x1, y1, x2, y2, duration_ms)
    checkpoint()
    x1, y1 = tonumber(x1) or 0, tonumber(y1) or 0
    x2, y2 = tonumber(x2) or 0, tonumber(y2) or 0
    duration_ms = tonumber(duration_ms) or 400
    local dist = math.max(math.abs(x2 - x1), math.abs(y2 - y1), 1)
    local step = math.max(4, math.floor(dist / 20))
    local n = math.max(1, math.floor(dist / step))
    local ms = math.max(1, math.floor(duration_ms / n))
    return moveTo(x1, y1, x2, y2, step, ms)
  end

  _G.__ZIYAN_TOUCH_HID = true
  return M
end

return M
