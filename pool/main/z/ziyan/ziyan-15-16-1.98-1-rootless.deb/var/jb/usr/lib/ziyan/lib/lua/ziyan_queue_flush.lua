-- zydaemon-only worker: no ziyan_run.lua, business session, or embed markers.
local root = (arg and arg[1]) or "/usr/lib/ziyan"
_G.ZIYAN_ROOT = root
_G.ZIYAN_VAR = root .. "/var"
_G.ZIYAN_LUA = root .. "/lib/lua"
package.path = table.concat({
  ZIYAN_LUA .. "/?.lua", ZIYAN_LUA .. "/modules/?.lua",
  ZIYAN_LUA .. "/ziyan_engine/?.lua", package.path,
}, ";")

local ok_cv, cv = pcall(dofile, ZIYAN_LUA .. "/ziyan_engine/py_cv.lua")
if ok_cv and type(cv) == "table" and type(cv.install) == "function" then
  pcall(cv.install)
end
for _, name in ipairs({ "OfflineQueue", "FtpErrorUploader" }) do
  local ok, queue = pcall(dofile, ZIYAN_LUA .. "/modules/" .. name .. ".lua")
  if ok and type(queue) == "table" and type(queue.flush) == "function" then
    local flushed, stats = pcall(queue.flush, { timeout = 2, batch = 2 })
    if not flushed then
      io.stderr:write(name .. " flush failed: " .. tostring(stats) .. "\n")
    end
  else
    io.stderr:write(name .. " load failed: " .. tostring(queue) .. "\n")
  end
end
